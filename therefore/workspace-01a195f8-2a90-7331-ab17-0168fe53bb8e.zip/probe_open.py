import wave, numpy as np
from faster_whisper import WhisperModel
def load(path, t0=0, t1=None):
    w=wave.open(path,'rb'); sr=w.getframerate(); ch=w.getnchannels()
    a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768
    a=a.reshape(-1,ch).mean(1)
    a=a[int(t0*sr):int((t1 if t1 else len(a)/sr)*sr)]
    nt=np.arange(0,len(a)/sr,1/16000)
    return np.interp(nt,np.arange(len(a))/sr,a).astype(np.float32)

cfg=[("small.en", None, False), ("distil-medium.en", None, False),
     ("small.en", "Gu Zhen Ren, Reverend Insanity, author's notes, webnovel.", False),
     ("distil-medium.en", "Gu Zhen Ren, Reverend Insanity, author's notes, webnovel.", True)]
audio=load("uploads/source.bin",0,19)
for size,prompt,vad in cfg:
    m=WhisperModel(size,device="cpu",compute_type="int8",cpu_threads=2)
    segs,_=m.transcribe(audio,language="en",beam_size=8,best_of=8,
        initial_prompt=prompt, temperature=[0.0,0.2],
        vad_filter=vad, condition_on_previous_text=False)
    print(f"\n=== {size} prompt={bool(prompt)} vad={vad}")
    for s in segs: print(f"  [{s.start:5.2f}-{s.end:5.2f}] {s.text.strip()}")
    del m
