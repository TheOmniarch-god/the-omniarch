import wave, numpy as np
from scipy import signal as sg
from faster_whisper import WhisperModel
w=wave.open('uploads/source.bin','rb'); sr=w.getframerate(); ch=w.getnchannels()
a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768
a=a.reshape(-1,ch).mean(1)
b,aa=sg.butter(2,120/(sr/2),btype='high'); a=sg.lfilter(b,aa,a)
x=a[int(6.6*sr):int(17.2*sr)]
m=WhisperModel("distil-medium.en",device="cpu",compute_type="int8",cpu_threads=2)
for speed in (0.55,0.75,1.0):
    nt=np.arange(0,len(x)/sr,1/(16000*speed))
    y=np.interp(nt,np.arange(len(x))/sr,x).astype(np.float32)
    y=y/max(1e-6,np.abs(y).max())*0.95
    for temp in (0.0,0.4):
        segs,_=m.transcribe(y,language="en",beam_size=10,best_of=10,temperature=[temp],
                            vad_filter=False, condition_on_previous_text=False, no_speech_threshold=0.9)
        print(f"-- speed {speed} temp {temp}:", " | ".join(s.text.strip() for s in segs))
