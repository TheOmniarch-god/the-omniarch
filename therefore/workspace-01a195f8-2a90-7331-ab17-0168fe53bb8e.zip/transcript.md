# “Where has Gu Zhen Ren been?” — LOCKED transcript

**Audio:** `narration.wav` — 106.28 s (cut from the 108.4 s source so the film ends on the word *“hope.”*)
**Context:** Gu Zhen Ren's September 23 author's note on Qidian (*Immortal Puppet Master* / 仙工开物)

| # | in | out | line |
|---|---|---|---|
| 1 | 0:01.0 | 0:06.6 | For anyone wondering where Gu Zhen Ren has been over the past month — or the past while — |
| 2 | 0:06.6 | 0:15.9 | he posted something during September 23rd. And in his author's notes in **Immortal Puppet Master** on **Qidian**, |
| 3 | 0:15.9 | 0:22.3 | he spoke about the brutality of years spent glued to a desk with dreadful sleep schedules. |
| 4 | 0:22.3 | 0:29.6 | All of which caught up with him, and it had manifested as **debilitating** physical fatigue and severe insomnia, |
| 5 | 0:29.6 | 0:39.5 | which a **hospital report** assessment subsequently confirmed was compounded by a mild depressive state and anxiety. |
| 6 | 0:39.5 | 0:47.4 | So rather than forcing out half-hearted chapters and bad writing that would compromise the quality of the narrative, |
| 7 | 0:47.4 | 0:53.1 | he has been properly looking after himself under medical guidance — incorporating medication, psychological counselling, daily walks, |
| 8 | 0:53.1 | 1:03.3 | and a deliberate digital detox to clear the mental fog. |
| 9 | 1:03.3 | 1:09.6 | The good news is that his treatment has been progressing nicely, and he's genuinely on the mend. |
| 10 | 1:09.6 | 1:18.2 | Why isn't he rushing straight back into an exhausting schedule of writing? Because he's still recovering — |
| 11 | 1:18.2 | 1:26.1 | he's gradually rebuilding his writing stamina through short daily desk sessions, until he reaches a sustainable pace. |
| 12 | 1:26.1 | 1:34.2 | So he's been very down — and he wrote a lot after the ban of Gu Zhen Ren. |
| 13 | 1:34.2 | 1:42.1 | It's been a long time, but when I'm reading those, it's so depressing — how he sees life sometimes. |
| 14 | 1:42.1 | **1:46.0** | It's very sad, but he has a lot of hope. **[END]** |

**Confirmed by you:**
* “hospital report” ✔
* film ends on **“hope”** — the trailing *“and type shit”* is cut from the audio ✔

**Still assuming (say if wrong):**
* “Immortal Puppet Master” (仙工开物) and “Qidian” are the right proper nouns
* “debilitating physical fatigue” (not “deliberately”)
* “Because he's still recovering” — machine heard “because he's been progressing”

`cues.json` holds the same 14 beats as machine-readable timings — every shot in the film will be cut to it.
