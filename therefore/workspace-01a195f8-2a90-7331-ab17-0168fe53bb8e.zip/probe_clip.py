import wave, numpy as np, sys
from faster_whisper import WhisperModel
w=wave.open('uploads/source.bin','rb'); sr=w.getframerate(); ch=w.getnchannels()
a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768
a=a.reshape(-1,ch).mean(1)
def clip(t0,t1):
    x=a[int(t0*sr):int(t1*sr)]
    nt=np.arange(0,len(x)/sr,1/16000)
    y=np.interp(nt,np.arange(len(x))/sr,x).astype(np.float32)
    return y/max(1e-6,np.abs(y).max())*0.95
size=sys.argv[1]
m=WhisperModel(size,device="cpu",compute_type="int8",cpu_threads=2)
for (t0,t1) in [(6.8,17.0),(0.5,17.0)]:
    segs,_=m.transcribe(clip(t0,t1),language="en",beam_size=10,best_of=10,
        temperature=[0.0,0.2,0.4,0.6], vad_filter=False, condition_on_previous_text=False)
    print(f"== {size} [{t0}-{t1}]")
    for s in segs: print("   ", s.text.strip())
