const puppeteer=require('puppeteer'),path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'shell',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const p=await b.newPage(); p.on('pageerror',e=>console.log('ERR',e.message));
p.on('console',m=>console.log('LOG',m.text()));
await p.goto('file://'+path.join(__dirname,'preview.html')+'?solo',{waitUntil:'load'});
await p.waitForFunction('window.__ready===true',{timeout:60000});
const r=await p.evaluate(()=>{
  const g = window.__gu.skull.geometry;
  const pos=g.attributes.position; let maxZ=-9, maxZY=0, far=0;
  const F=y=>headProfile(y).dF;
  for(let i=0;i<pos.count;i++){const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i);
    if(Math.abs(x)<0.004 && y>-0.06 && y<0.05){ const d=z-F(y); if(d>far){far=d;maxZY=y;} }
    if(z>maxZ){maxZ=z;}}
  return {count:pos.count, far, maxZY, maxZ, headKids: window.__gu.head.children.length};
});
console.log(JSON.stringify(r));
await b.close();})();
