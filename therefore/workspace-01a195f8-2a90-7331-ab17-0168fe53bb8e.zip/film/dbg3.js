const puppeteer=require('puppeteer'),path=require('path');
const shots=[
 {n:'front',o:{px:0.00,py:1.19,pz:-0.85,tx:0,ty:1.185,tz:-1.39,fov:30}},
 {n:'34',   o:{px:0.30,py:1.20,pz:-0.92,tx:0,ty:1.185,tz:-1.39,fov:30}},
 {n:'prof', o:{px:0.62,py:1.19,pz:-1.39,tx:0,ty:1.185,tz:-1.39,fov:30}}
];
(async()=>{
const b=await puppeteer.launch({headless:'shell',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const p=await b.newPage(); await p.setViewport({width:900,height:900});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file://'+path.join(__dirname,'preview.html')+'?solo',{waitUntil:'load'});
await p.waitForFunction('window.__ready===true',{timeout:60000});
await p.evaluate(()=>window.__light([-0.85,0.32,0.30],0.035,1.0));
for(const s of shots){
  await p.evaluate(o=>window.__look(o),s.o);
  await p.evaluate(()=>window.__setTime(0));
  await p.screenshot({path:'prev/f-'+s.n+'.png'});
}
await b.close();})();
