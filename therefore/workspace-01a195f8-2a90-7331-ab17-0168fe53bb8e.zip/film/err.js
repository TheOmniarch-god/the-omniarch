const puppeteer=require('puppeteer'),path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'shell',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const p=await b.newPage();
p.on('pageerror',e=>console.log('PAGEERR',e.stack));
p.on('console',m=>console.log(m.type().toUpperCase(),m.text()));
await p.goto('file://'+path.join(__dirname,'preview.html')+'?solo',{waitUntil:'load'});
await new Promise(r=>setTimeout(r,4000));
console.log('ready=',await p.evaluate(()=>window.__ready));
await b.close();})();
