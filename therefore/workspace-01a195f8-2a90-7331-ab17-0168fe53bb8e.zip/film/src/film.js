/* =========================================================================
   GU ZHEN REN — "with hope"  ·  look-test driver (study portrait)
   ========================================================================= */
(function () {
  'use strict';
  const canvas = document.getElementById('c');
  initRenderer(canvas);
  renderer.setSize(window.innerWidth, window.innerHeight, false);
  const post = initPost();

  camera.aspect = window.innerWidth / window.innerHeight;
  camera.fov = 32;
  camera.updateProjectionMatrix();

  // ---- lighting for the study (cool window light, warm bounce) ------------
  const LIGHT = {
    keyDir: V3(-0.72, 0.45, 0.52).normalize(),
    keyCol: new THREE.Color(0.86, 0.92, 1.0),
    fillDir: V3(0.75, 0.30, 0.35).normalize(),
    fillCol: new THREE.Color(0.20, 0.13, 0.07),
    amb: new THREE.Color(0.13, 0.12, 0.13),
    rimC: new THREE.Color(0.55, 0.68, 0.80)
  };
  LIGHTS.keyDir.copy(LIGHT.keyDir);
  LIGHTS.keyCol.copy(LIGHT.keyCol);
  LIGHTS.fillDir.copy(LIGHT.fillDir);
  LIGHTS.fillCol.copy(LIGHT.fillCol);
  LIGHTS.amb.copy(LIGHT.amb);
  LIGHTS.fogC.set(0.05, 0.045, 0.045);
  LIGHTS.fogNear = 30; LIGHTS.fogFar = 90;

  const SOLO = /solo/.test(location.search);
  const study = buildStudy();
  if (!SOLO) { scene.add(study); applyLighting(study, LIGHT); }
  else { scene.background = new THREE.Color(0x14161a); scene.fog = null; }

  const gu = buildGu();
  gu.body.position.set(study.userData.guSpot.x, study.userData.guSpot.y, study.userData.guSpot.z);
  gu.body.rotation.y = 0.18;
  gu.pose({
    armL: { z: 0.20, fx: -0.55 },   // forearm resting on the armrest
    armR: { z: -0.16, fx: -0.65 },
    headX: 0.02, headY: -0.10, headZ: 0.02
  });
  scene.add(gu.body);
  applyLighting(gu.body, LIGHT);

  // ---- camera ------------------------------------------------------------
  const camTarget = { pos: V3(0.62, 1.34, 0.14), look: V3(0.0, 1.12, -1.40) };
  window.__eyes = () => eyeTexture;
  window.__light = (dir, amb, key) => {
    LIGHTS.keyDir.set(dir[0], dir[1], dir[2]).normalize();
    LIGHTS.amb.set(amb, amb, amb);
    LIGHTS.keyCol.set(key, key, key);
    LIGHTS.fillCol.set(0.04, 0.035, 0.03);
  };
  window.__look = o => {
    if (o.fov) { camera.fov = o.fov; camera.updateProjectionMatrix(); }
    camTarget.pos.set(o.px, o.py, o.pz);
    camTarget.look.set(o.tx, o.ty, o.tz);
  };
  window.__pose = p => gu.pose(p);
  window.__kids = () => window.__gu.head.children.map((c, i) => i + ':' + c.type + ':' + (c.name || '') + ':' + (c.geometry ? c.geometry.attributes.position.count : 0));
  window.__vis = (i, v) => { window.__gu.head.children[i].visible = v; };
  window.__gu = gu;
  window.__scene = scene;

  function shoot(t) {
    study.userData.update(t);
    // character life
    const G = gu;
    G.body.position.y = study.userData.guSpot.y + Math.sin(t * 1.1) * 0.0035;
    const blinkT = (t * 0.41 + 2.1) % 4.4;
    let blink = 0;
    if (blinkT < 0.14) blink = Math.sin(blinkT / 0.14 * Math.PI);
    {
      const f = G.head.userData.face;
      if (f && f.setBlink) f.setBlink(blink);
    }
    G.headMount.rotation.y = -0.10 + Math.sin(t * 0.27) * 0.025;
    G.headMount.rotation.z = 0.02 + Math.sin(t * 0.21) * 0.01;

    camera.position.copy(camTarget.pos);
    camera.lookAt(camTarget.look);
    camera.updateMatrixWorld();

    renderer.setRenderTarget(post.rt);
    renderer.clear();
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);
    post.postMat.uniforms.uTime.value = t;
    post.postMat.uniforms.uFade.value = 0;
    renderer.render(post.postScene, post.postCam);
  }

  window.__setTime = t => shoot(t);
  window.__ready = true;
  shoot(0);
})();
