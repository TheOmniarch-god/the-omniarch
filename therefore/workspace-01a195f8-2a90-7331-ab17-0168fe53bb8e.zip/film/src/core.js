/* =========================================================================
   CORE — renderer, painterly material, procedural textures, post grade.
   ========================================================================= */
const V3 = (x, y, z) => new THREE.Vector3(x, y, z);
const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = x => Math.min(1, Math.max(0, x));
const smooth = (a, b, x) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const smoothstep = (a, b, x) => smooth(a, b, x);
const rand = (a, b) => a + Math.random() * (b - a);
const rad = d => d * Math.PI / 180;

/* ------------------------------------------------------------------ canvas */
function cnv(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}
function tex(canvas, opt) {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (opt && opt.repeat) t.repeat.set(opt.repeat[0], opt.repeat[1]);
  t.anisotropy = 4;
  return t;
}
function noiseFill(ctx, w, h, amount, alpha) {
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (Math.random() - 0.5) * amount;
    d[i] += n; d[i + 1] += n; d[i + 2] += n;
  }
  ctx.putImageData(img, 0, 0);
}

/* --------------------------------------------------------------- textures */
const TEX = {};
function buildTextures() {
  // ---- gold palm-frond mural (the hero wall from the reference) ----------
  {
    const w = 1024, h = 512, c = cnv(w, h), x = c.getContext('2d');
    const g = x.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, '#8a5f14'); g.addColorStop(0.35, '#c99a3f');
    g.addColorStop(0.62, '#e0b559'); g.addColorStop(1, '#7d5512');
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    // radiating fronds
    function frond(cx, cy, ang, len, wid, col, alpha) {
      x.save(); x.translate(cx, cy); x.rotate(ang);
      x.globalAlpha = alpha; x.fillStyle = col;
      x.beginPath(); x.moveTo(0, 0);
      for (let i = 0; i <= 12; i++) {
        const t = i / 12, px = t * len;
        const py = Math.sin(t * Math.PI) * wid;
        x.lineTo(px, -py);
      }
      for (let i = 12; i >= 0; i--) {
        const t = i / 12, px = t * len;
        const py = Math.sin(t * Math.PI) * wid * 0.55;
        x.lineTo(px, py);
      }
      x.closePath(); x.fill();
      // leaflets
      x.strokeStyle = col; x.lineWidth = 2.5; x.globalAlpha = alpha * 0.85;
      for (let i = 1; i < 20; i++) {
        const t = i / 20, px = t * len;
        const py = Math.sin(t * Math.PI) * wid;
        x.beginPath(); x.moveTo(px, 0); x.lineTo(px + 14, -py * 1.35); x.stroke();
        x.beginPath(); x.moveTo(px, 0); x.lineTo(px + 14, py * 1.35); x.stroke();
      }
      x.restore();
    }
    const cols = ['#f0cc7a', '#b8862c', '#6d4a0e', '#f7dda0', '#94661a'];
    for (let i = 0; i < 26; i++) {
      frond(rand(-40, w + 40), rand(-40, h + 40), rand(0, Math.PI * 2),
        rand(90, 260), rand(22, 60), cols[i % cols.length], rand(0.35, 0.9));
    }
    // painterly strokes over the top
    x.globalAlpha = 0.20;
    for (let i = 0; i < 900; i++) {
      x.strokeStyle = Math.random() < 0.5 ? '#ffe6ad' : '#5c3d08';
      x.lineWidth = rand(1, 4);
      const px = Math.random() * w, py = Math.random() * h;
      x.beginPath(); x.moveTo(px, py);
      x.quadraticCurveTo(px + rand(-30, 30), py + rand(-18, 18), px + rand(-60, 60), py + rand(-30, 30));
      x.stroke();
    }
    x.globalAlpha = 1;
    noiseFill(x, w, h, 16);
    TEX.gold = tex(c);
  }
  // ---- wall moulding / paint --------------------------------------------
  {
    const w = 512, h = 512, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#b8b7a8'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 2600; i++) {
      x.globalAlpha = rand(0.01, 0.05);
      x.fillStyle = Math.random() < 0.5 ? '#ffffff' : '#6f6f63';
      const s = rand(4, 26);
      x.beginPath(); x.ellipse(rand(0, w), rand(0, h), s, s * rand(0.2, 0.6), rand(0, 3), 0, 6.3); x.fill();
    }
    x.globalAlpha = 1; noiseFill(x, w, h, 10);
    TEX.wall = tex(c);
  }
  // ---- green marble / moulding ------------------------------------------
  {
    const w = 256, h = 256, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#6d7a63'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 40; i++) {
      x.strokeStyle = Math.random() < 0.5 ? '#89957c' : '#4c5844';
      x.lineWidth = rand(1, 6); x.globalAlpha = rand(0.1, 0.4);
      x.beginPath(); x.moveTo(rand(0, w), 0);
      x.bezierCurveTo(rand(0, w), h * 0.3, rand(0, w), h * 0.7, rand(0, w), h);
      x.stroke();
    }
    x.globalAlpha = 1; noiseFill(x, w, h, 12);
    TEX.marble = tex(c);
  }
  // ---- leather ----------------------------------------------------------
  {
    const w = 512, h = 512, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#2a211c'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 2600; i++) {
      x.globalAlpha = rand(0.02, 0.12);
      x.fillStyle = Math.random() < 0.5 ? '#5b4232' : '#171210';
      const s = rand(6, 40);
      x.beginPath(); x.ellipse(rand(0, w), rand(0, h), s, s * rand(0.4, 1), rand(0, 3), 0, 6.3); x.fill();
    }
    x.globalAlpha = 1; noiseFill(x, w, h, 22);
    TEX.leather = tex(c);
  }
  // ---- wood -------------------------------------------------------------
  {
    const w = 512, h = 512, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#5a3f28'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 200; i++) {
      x.strokeStyle = Math.random() < 0.5 ? '#704e31' : '#422c1b';
      x.lineWidth = rand(1, 9); x.globalAlpha = rand(0.08, 0.35);
      const y0 = rand(0, h);
      x.beginPath(); x.moveTo(0, y0);
      x.bezierCurveTo(w * 0.3, y0 + rand(-16, 16), w * 0.7, y0 + rand(-16, 16), w, y0 + rand(-24, 24));
      x.stroke();
    }
    x.globalAlpha = 1; noiseFill(x, w, h, 14);
    TEX.wood = tex(c);
  }
  // ---- paper ------------------------------------------------------------
  {
    const w = 512, h = 512, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#e6dcc4'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 1400; i++) {
      x.globalAlpha = rand(0.01, 0.05);
      x.fillStyle = Math.random() < 0.5 ? '#fffdf2' : '#a89a7c';
      x.beginPath(); x.ellipse(rand(0, w), rand(0, h), rand(3, 18), rand(2, 9), rand(0, 3), 0, 6.3); x.fill();
    }
    x.globalAlpha = 1; noiseFill(x, w, h, 12);
    TEX.paper = tex(c);
  }
  // ---- fabric (suit) ----------------------------------------------------
  {
    const w = 256, h = 256, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < w; i += 3) {
      x.globalAlpha = 0.10; x.fillStyle = '#000';
      x.fillRect(i, 0, 1, h);
    }
    for (let j = 0; j < h; j += 3) {
      x.globalAlpha = 0.06; x.fillStyle = '#000';
      x.fillRect(0, j, w, 1);
    }
    x.globalAlpha = 1; noiseFill(x, w, h, 18);
    TEX.fabric = tex(c);
  }
  // ---- skin mottling ----------------------------------------------------
  {
    const w = 256, h = 256, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 900; i++) {
      x.globalAlpha = rand(0.02, 0.08);
      x.fillStyle = Math.random() < 0.55 ? '#ffd9c4' : '#c08a72';
      x.beginPath(); x.ellipse(rand(0, w), rand(0, h), rand(4, 22), rand(3, 14), rand(0, 3), 0, 6.3); x.fill();
    }
    x.globalAlpha = 1; noiseFill(x, w, h, 8);
    TEX.skin = tex(c);
  }
  // ---- hair -------------------------------------------------------------
  {
    const w = 512, h = 256, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 700; i++) {
      x.strokeStyle = Math.random() < 0.5 ? '#ffffff' : '#9a8b86';
      x.lineWidth = rand(1, 3); x.globalAlpha = rand(0.05, 0.3);
      const y0 = rand(0, h);
      x.beginPath(); x.moveTo(rand(-40, 60), y0);
      x.quadraticCurveTo(w * 0.5, y0 + rand(-30, 30), w + 40, y0 + rand(-40, 40));
      x.stroke();
    }
    x.globalAlpha = 1;
    TEX.hair = tex(c);
  }
  // ---- rainy window -----------------------------------------------------
  {
    const w = 512, h = 512, c = cnv(w, h), x = c.getContext('2d');
    const g = x.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#8fa5b0'); g.addColorStop(0.45, '#a9bcc2');
    g.addColorStop(0.62, '#c3d0d2'); g.addColorStop(1, '#8a9aa0');
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    // blurred city
    x.globalAlpha = 0.5;
    for (let i = 0; i < 40; i++) {
      x.fillStyle = '#6f8087';
      const bw = rand(20, 80), bh = rand(40, 200);
      x.fillRect(rand(-20, w), h * 0.55 - bh + rand(-10, 30), bw, bh);
    }
    x.globalAlpha = 1;
    // rain streaks on the glass
    for (let i = 0; i < 220; i++) {
      const px = rand(0, w), py = rand(0, h), ln = rand(10, 90);
      x.strokeStyle = 'rgba(255,255,255,' + rand(0.05, 0.25).toFixed(2) + ')';
      x.lineWidth = rand(0.6, 2.2);
      x.beginPath(); x.moveTo(px, py); x.lineTo(px + rand(-6, 6), py + ln); x.stroke();
    }
    for (let i = 0; i < 500; i++) {
      x.fillStyle = 'rgba(255,255,255,' + rand(0.05, 0.3).toFixed(2) + ')';
      x.beginPath(); x.arc(rand(0, w), rand(0, h), rand(0.6, 2.4), 0, 6.3); x.fill();
    }
    TEX.rain = tex(c);
  }
  // ---- book spines ------------------------------------------------------
  {
    const w = 512, h = 256, c = cnv(w, h), x = c.getContext('2d');
    x.fillStyle = '#3a2a1e'; x.fillRect(0, 0, w, h);
    const cols = ['#7a2f24', '#2f4a3c', '#3c3a5c', '#7a6a2c', '#5c2f3c', '#2c3f52'];
    let px = 0;
    while (px < w) {
      const bw = rand(8, 22);
      x.fillStyle = cols[Math.floor(Math.random() * cols.length)];
      x.fillRect(px, 0, bw, h);
      x.fillStyle = 'rgba(0,0,0,0.35)'; x.fillRect(px, 0, 1.5, h);
      x.fillStyle = 'rgba(255,240,200,' + rand(0.1, 0.35) + ')';
      x.fillRect(px + bw * 0.3, rand(20, h * 0.4), bw * 0.4, rand(2, 5));
      px += bw + rand(0.5, 2);
    }
    noiseFill(x, w, h, 16);
    TEX.books = tex(c);
  }
}

/* ------------------------------------------------------- painterly material */
const PAINT_VS = `
  varying vec3 vN; varying vec3 vW; varying vec2 vUv;
#ifdef HAS_VCOL
  attribute vec3 vcol; varying vec3 vVCol;
#endif
  void main(){
#ifdef HAS_VCOL
    vVCol = vcol;
#endif
    vUv = uv;
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vW = wp.xyz;
    vN = normalize(mat3(modelMatrix) * normal);
    gl_Position = projectionMatrix * viewMatrix * wp;
  }`;

const PAINT_FS = `
  uniform vec3 uColor, uShadow, uHi, uRimC, uAmb, uFogC;
  uniform vec3 uKeyDir, uKeyCol, uFillDir, uFillCol;
  uniform float uRampLo, uRampHi, uRim, uSpec, uShine, uTexAmt, uAlpha, uFogNear, uFogFar, uEmis;
  uniform sampler2D uTex;
  uniform float uHasTex;
  uniform sampler2D uMap;
  uniform float uHasMap, uMapAmt;
  varying vec3 vN; varying vec3 vW; varying vec2 vUv;
#ifdef HAS_VCOL
  varying vec3 vVCol;
#endif

  void main(){
    vec3 N = normalize(vN);
    vec3 V = normalize(cameraPosition - vW);
    if (dot(N, V) < 0.0 && uAlpha > 0.99) N = -N;

    float ndl = dot(N, normalize(uKeyDir));
    float w = ndl * 0.5 + 0.5;
    float ramp = smoothstep(uRampLo, uRampHi, w);
    vec3 col = mix(uShadow, uColor, ramp);
    col = mix(col, uHi, smoothstep(0.80, 1.0, w) * 0.6);
    col *= uKeyCol;

    float fdl = dot(N, normalize(uFillDir)) * 0.5 + 0.5;
    col += uFillCol * pow(fdl, 2.2) * 0.55;

    col += uAmb * (0.62 + 0.38 * N.y);

    float rim = pow(1.0 - max(dot(N, V), 0.0), 3.2);
    col += uRimC * rim * uRim;

    vec3 H = normalize(normalize(uKeyDir) + V);
    col += vec3(1.0, 0.97, 0.93) * pow(max(dot(N, H), 0.0), uShine) * uSpec;

    col += uColor * uEmis;

    if (uHasTex > 0.5) {
      vec3 t = texture2D(uTex, vUv).rgb;
      col *= mix(vec3(1.0), t * 1.06, uTexAmt);
    }

#ifdef HAS_VCOL
    {
      vec3 shade = col / max(uColor, vec3(0.06));
      col = shade * mix(uColor, vVCol, uMapAmt);
    }
#endif
    if (uHasMap > 0.5) {
      // the map carries its own albedo; reuse the computed lighting ratio
      vec3 shade = col / max(uColor, vec3(0.06));
      vec4 m = texture2D(uMap, vUv);
      vec3 albedo = mix(uColor, m.rgb, uMapAmt);
      col = shade * albedo;
    }

    float d = length(cameraPosition - vW);
    float f = smoothstep(uFogNear, uFogFar, d);
    col = mix(col, uFogC, f);

    gl_FragColor = vec4(col, uAlpha);
  }`;

const LIGHTS = {
  keyDir: V3(-0.5, 0.65, 0.58).normalize(),
  keyCol: new THREE.Color(1.0, 0.98, 0.94),
  fillDir: V3(0.6, 0.1, 0.4).normalize(),
  fillCol: new THREE.Color(0.16, 0.19, 0.24),
  amb: new THREE.Color(0.20, 0.21, 0.24),
  fogC: new THREE.Color(0.10, 0.10, 0.12),
  fogNear: 60, fogFar: 200
};

function paintMat(o) {
  o = o || {};
  const m = new THREE.ShaderMaterial({
    vertexShader: PAINT_VS,
    fragmentShader: PAINT_FS,
    transparent: !!o.transparent,
    side: o.side || THREE.FrontSide,
    defines: o.vcol ? { HAS_VCOL: 1 } : {},
    depthWrite: o.depthWrite === undefined ? true : o.depthWrite,
    uniforms: {
      uColor: { value: new THREE.Color(o.color === undefined ? 0xcccccc : o.color) },
      uShadow: { value: new THREE.Color(o.shadow === undefined ? 0x2a2a30 : o.shadow) },
      uHi: { value: new THREE.Color(o.hi === undefined ? 0xffffff : o.hi) },
      uRimC: { value: new THREE.Color(o.rimColor === undefined ? 0xbcd8e8 : o.rimColor) },
      uAmb: { value: new THREE.Color(o.amb === undefined ? 0x33363c : o.amb) },
      uKeyDir: { value: (o.keyDir || LIGHTS.keyDir).clone() },
      uKeyCol: { value: (o.keyCol || LIGHTS.keyCol).clone() },
      uFillDir: { value: (o.fillDir || LIGHTS.fillDir).clone() },
      uFillCol: { value: (o.fillCol || LIGHTS.fillCol).clone() },
      uRampLo: { value: o.rampLo === undefined ? 0.22 : o.rampLo },
      uRampHi: { value: o.rampHi === undefined ? 0.62 : o.rampHi },
      uRim: { value: o.rim === undefined ? 0.35 : o.rim },
      uSpec: { value: o.spec === undefined ? 0.0 : o.spec },
      uShine: { value: o.shine === undefined ? 24 : o.shine },
      uTexAmt: { value: o.texAmt === undefined ? 0.0 : o.texAmt },
      uAlpha: { value: o.opacity === undefined ? 1 : o.opacity },
      uEmis: { value: o.emis === undefined ? 0 : o.emis },
      uTex: { value: o.tex || TEX.wall },
      uHasTex: { value: o.tex ? 1 : 0 },
      uMap: { value: o.map || TEX.skin },
      uHasMap: { value: o.map ? 1 : 0 },
      uMapAmt: { value: o.mapAmt === undefined ? 1 : o.mapAmt },
      uFogC: { value: (o.fogColor || LIGHTS.fogC).clone() },
      uFogNear: { value: o.fogNear === undefined ? LIGHTS.fogNear : o.fogNear },
      uFogFar: { value: o.fogFar === undefined ? LIGHTS.fogFar : o.fogFar }
    }
  });
  m.userData.kind = 'paint';
  return m;
}
function setLight(m, key) {
  Object.keys(key).forEach(k => {
    const u = m.uniforms['u' + k[0].toUpperCase() + k.slice(1)];
    if (u) { if (u.value.isColor) u.value.copy(key[k]); else u.value.copy(key[k]); }
  });
}

/* ------------------------------------------------------------- geometry kit */
function bake(items) {
  const pos = [], nor = [], uv = [];
  for (const it of items) {
    let g = it.geo.index ? it.geo.toNonIndexed() : it.geo.clone();
    if (it.matrix) g.applyMatrix4(it.matrix);
    if (!g.attributes.normal) g.computeVertexNormals();
    const p = g.attributes.position.array, n = g.attributes.normal.array;
    const u = g.attributes.uv ? g.attributes.uv.array : null;
    for (let i = 0; i < p.length; i += 3) { pos.push(p[i], p[i + 1], p[i + 2]); nor.push(n[i], n[i + 1], n[i + 2]); }
    if (u) for (let i = 0; i < u.length; i++) uv.push(u[i]);
    else for (let i = 0; i < p.length / 3 * 2; i++) uv.push(0);
    g.dispose();
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geo.computeBoundingSphere();
  return geo;
}
const MX = (x, y, z, rx, ry, rz, sx, sy, sz) => new THREE.Matrix4().compose(
  V3(x || 0, y || 0, z || 0),
  new THREE.Quaternion().setFromEuler(new THREE.Euler(rx || 0, ry || 0, rz || 0)),
  V3(sx === undefined ? 1 : sx, sy === undefined ? (sx === undefined ? 1 : sx) : sy, sz === undefined ? (sx === undefined ? 1 : sx) : sz));

/* -------------------------------------------------------------- soft shadow */
function shadowDecal(w, h, opacity, color) {
  const c = cnv(128, 128), x = c.getContext('2d');
  const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(0,0,0,' + opacity + ')');
  g.addColorStop(0.5, 'rgba(0,0,0,' + opacity * 0.55 + ')');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({
    map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false,
    color: color === undefined ? 0x000000 : color, blending: THREE.NormalBlending, fog: false
  }));
  m.rotation.x = -Math.PI / 2;
  m.renderOrder = 3;
  return m;
}

/* -------------------------------------------------------------- renderer+post */
let renderer, scene, camera, rtScene, rtCam, postMat, W = 1600, H = 900;

/* =========================================================================
   LOFTING KIT — build garments as stacks of rings so surfaces follow a body
   ========================================================================= */
function superRing(n, w, d, p, a0, a1) {
  const pts = [], span = a1 - a0;
  for (let i = 0; i <= n; i++) {
    const a = a0 + span * (i / n);
    const c = Math.cos(a), s = Math.sin(a);
    const x = w * Math.sign(c) * Math.pow(Math.abs(c), p);
    const z = d * Math.sign(s) * Math.pow(Math.abs(s), p);
    pts.push(new THREE.Vector2(x, z));
  }
  return pts;
}

/* secs: [{y, w, d, p, x, z, a0, a1}] — a0/a1 given => open arc shell */
function loftSections(secs, opts) {
  opts = opts || {};
  const n = opts.n || 32;
  const closed = secs[0].a0 === undefined;
  const rings = secs.map(sec => {
    const a0 = closed ? 0 : sec.a0, a1 = closed ? Math.PI * 2 : sec.a1;
    const r = superRing(n, sec.w, sec.d, sec.p === undefined ? 0.82 : sec.p, a0, a1);
    return r.map(v => new THREE.Vector3(v.x + (sec.x || 0), sec.y, v.y + (sec.z || 0)));
  });
  const N = rings[0].length;
  const pos = [], idx = [];
  for (let k = 0; k < rings.length; k++)
    for (let i = 0; i < N; i++) pos.push(rings[k][i].x, rings[k][i].y, rings[k][i].z);
  for (let k = 0; k < rings.length - 1; k++) {
    const lim = closed ? N : N - 1;
    for (let i = 0; i < lim; i++) {
      const a = k * N + i, b = k * N + (i + 1) % N, c = (k + 1) * N + i, d = (k + 1) * N + (i + 1) % N;
      idx.push(a, c, b, b, c, d);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

/* a garment shell hugging a body profile: profile(y) -> {w,d,p,z} */
function shellFromProfile(y0, y1, steps, profile, angleOf, off, n) {
  const secs = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps, y = y0 + (y1 - y0) * t;
    const pr = profile(y), ang = angleOf(t, y);
    secs.push({ y: y, w: pr.w + off, d: pr.d + off, p: pr.p, z: pr.z || 0, a0: ang[0], a1: ang[1] });
  }
  return loftSections(secs, { n: n || 18 });
}

const POST_VS = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.H0, 1.0); }`;
const POST_FS = `
  uniform sampler2D tDiffuse; uniform vec2 uRes; uniform float uTime, uVig, uGrain, uFade, uAber, uSat;
  varying vec2 vUv;
  void main(){
    vec2 uv = vUv;
    vec2 d = uv - 0.5;
    float r2 = dot(d, d);
    // chromatic aberration toward the edges
    vec2 off = d * r2 * uAber * 0.02;
    vec3 col;
    col.r = texture2D(tDiffuse, uv + off).r;
    col.g = texture2D(tDiffuse, uv).g;
    col.b = texture2D(tDiffuse, uv - off).b;
    // gentle S-curve
    col = clamp((col - 0.5) * 1.06 + 0.5, 0.0, 1.5);
    col = pow(max(col, 0.0), vec3(1.02, 1.0, 0.99));
    // saturation
    float l = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(l), col, uSat);
    // vignette
    float vig = smoothstep(0.95, 0.25, r2 * uVig * 2.2);
    col *= mix(1.0, vig, 0.85);
    // grain
    float n = fract(sin(dot(uv * uRes + uTime * 91.7, vec2(12.9898, 78.233))) * 43758.5453);
    col += (n - 0.5) * uGrain;
    // fade to black
    col *= (1.0 - uFade);
    gl_FragColor = vec4(col, 1.0);
  }`;

function initRenderer(canvas) {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(1);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(35, 16 / 9, 0.05, 400);
  buildTextures();
}

function initPost() {
  // offscreen target + fullscreen grade pass
  const w = renderer.domElement.width, h = renderer.domElement.height;
  const rt = new THREE.WebGLRenderTarget(w, h, {
    minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
    format: THREE.RGBAFormat, type: THREE.UnsignedByteType, depthBuffer: true
  });
  const q = new THREE.PlaneGeometry(2, 2);
  postMat = new THREE.ShaderMaterial({
    vertexShader: POST_VS.replace('0.H0', '0.0'),
    fragmentShader: POST_FS,
    uniforms: {
      tDiffuse: { value: rt.texture }, uRes: { value: new THREE.Vector2(w, h) },
      uTime: { value: 0 }, uVig: { value: 0.55 }, uGrain: { value: 0.045 },
      uFade: { value: 0 }, uAber: { value: 0.6 }, uSat: { value: 1.05 }
    },
    depthTest: false, depthWrite: false
  });
  const postScene = new THREE.Scene();
  const quad = new THREE.Mesh(q, postMat);
  quad.frustumCulled = false;
  postScene.add(quad);
  const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  return { rt, postScene, postCam, postMat };
}
