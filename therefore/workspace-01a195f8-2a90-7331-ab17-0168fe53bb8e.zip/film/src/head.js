/* =========================================================================
   HEAD — Gu Zhen Ren.
   A single skull surface shaped by analytic anatomical features (brow ridge,
   nasal bridge and tip, alae, philtrum, lips, chin, cheekbones, eye sockets),
   a continuous scalp hair mass, painted eyes with texture-driven blinking.
   Local origin = head centre (mid ear).  +y up, +z forward.
   ========================================================================= */

const HEAD_RINGS = [
  // y,      halfW,  depthBack
  [0.1150, 0.017, 0.022],
  [0.1060, 0.040, 0.050],
  [0.0920, 0.058, 0.074],
  [0.0720, 0.070, 0.089],
  [0.0460, 0.0785, 0.097],
  [0.0200, 0.0812, 0.1000],
  [-0.0050, 0.0800, 0.0990],
  [-0.0220, 0.0772, 0.0965],
  [-0.0380, 0.0755, 0.0930],
  [-0.0550, 0.0678, 0.0865],
  [-0.0720, 0.0520, 0.0775],
  [-0.0880, 0.0405, 0.0660],
  [-0.1020, 0.0250, 0.0480],
  [-0.1120, 0.0105, 0.0270]
];

// base depth of the face plane (the "cheek plane", features are added on top)
const FACE_DF = [
  [0.1150, 0.020], [0.1000, 0.046], [0.0800, 0.068], [0.0600, 0.077],
  [0.0400, 0.0810], [0.0200, 0.0830], [0.0000, 0.0840], [-0.0200, 0.0835],
  [-0.0400, 0.0820], [-0.0600, 0.0790], [-0.0800, 0.0735], [-0.0980, 0.0700],
  [-0.1100, 0.0520], [-0.1150, 0.0300]
];

function curveAt(tbl, y) {
  if (y >= tbl[0][0]) return tbl[0][1];
  const last = tbl[tbl.length - 1];
  if (y <= last[0]) return last[1];
  for (let i = 0; i < tbl.length - 1; i++) {
    if (y <= tbl[i][0] && y >= tbl[i + 1][0]) {
      const t = (tbl[i][0] - y) / (tbl[i][0] - tbl[i + 1][0]);
      return lerp(tbl[i][1], tbl[i + 1][1], t);
    }
  }
  return last[1];
}
const HEAD_V0 = -0.132, HEAD_V1 = 0.128;
const SKIN_LIN = [Math.pow(216/255,2.2), Math.pow(168/255,2.2), Math.pow(135/255,2.2)];
const widthAt = y => curveAt(HEAD_RINGS.map(r => [r[0], r[1]]), y);
const depthBackAt = y => curveAt(HEAD_RINGS.map(r => [r[0], r[2]]), y);
const faceBase = y => curveAt(FACE_DF, y);

/* lateral mask: 1 at the midline, soft zero beyond `w` */
const lat = (x, w) => { const k = Math.min(1, Math.abs(x) / w); return Math.pow(Math.max(0, 1 - k * k), 1.5); };
const band = (y, y0, s0, s1) => {
  if (y > y0) return Math.exp(-Math.pow((y - y0) / s0, 2));
  return Math.exp(-Math.pow((y - y0) / s1, 2));
};

/* the facial relief: returns extra depth (+z) plus lateral pinch */
function faceRelief(x, y) {
  let dz = 0, dx = 0;
  // brow ridge
  dz += 0.0050 * band(y, 0.0270, 0.0130, 0.0110) * lat(x, 0.058) * (1 - 0.35 * lat(x, 0.014));
  // nasion dip between the brows
  dz -= 0.0020 * band(y, 0.0080, 0.0070, 0.0070) * lat(x, 0.016);
  // nose: bridge -> tip
  // (the nose itself is modelled as its own sculpted surface)
  // philtrum
  dz -= 0.0026 * band(y, -0.0585, 0.0075, 0.0060) * lat(x, 0.0075);
  // upper + lower lip
  dz += 0.0062 * band(y, -0.0672, 0.0062, 0.0045) * lat(x, 0.0235);
  dz += 0.0074 * band(y, -0.0762, 0.0045, 0.0068) * lat(x, 0.0215);
  dz -= 0.0032 * Math.exp(-Math.pow((y + 0.0717) / 0.0022, 2)) * lat(x, 0.0245);
  // mentolabial crease
  dz -= 0.0030 * band(y, -0.0865, 0.0060, 0.0055) * lat(x, 0.020);
  // chin
  dz += 0.0104 * band(y, -0.0975, 0.0095, 0.0060) * lat(x, 0.0225);
  // cheekbones + cheeks
  for (const s of [-1, 1]) {
    dz += 0.0040 * Math.exp(-(Math.pow((x - s * 0.0520) / 0.0230, 2) + Math.pow((y + 0.0070) / 0.0150, 2)));
    dz += 0.0034 * Math.exp(-(Math.pow((x - s * 0.0430) / 0.0250, 2) + Math.pow((y + 0.0330) / 0.0210, 2)));
    // eye socket
    dz -= 0.0064 * Math.exp(-(Math.pow((x - s * 0.0335) / 0.0225, 2) + Math.pow((y + 0.0030) / 0.0170, 2)));
    // temple hollow
    dx -= s * 0.0034 * Math.exp(-(Math.pow((x - s * 0.0760) / 0.0170, 2) + Math.pow((y - 0.0380) / 0.0250, 2)));
    // nasolabial fold
    dz -= 0.0034 * Math.exp(-(Math.pow((x - s * 0.0215) / 0.0062, 2) + Math.pow((y + 0.0510) / 0.0150, 2)));
    // under-eye bag (tiredness)
    dz += 0.0022 * Math.exp(-(Math.pow((x - s * 0.0330) / 0.0140, 2) + Math.pow((y + 0.0175) / 0.0055, 2)));
  }
  return { dz, dx };
}

/* dense skull grid */
function buildSkullGeo(rows, cols, pExp) {
  const y0 = HEAD_RINGS[0][0], y1 = HEAD_RINGS[HEAD_RINGS.length - 1][0];
  const pos = [], idx = [], uv = [];
  for (let r = 0; r <= rows; r++) {
    const y = lerp(y0, y1, Math.pow(r / rows, 1.08));
    const w = widthAt(y), dB = depthBackAt(y), dF = faceBase(y);
    for (let c = 0; c <= cols; c++) {
      const t = (c / cols) * 2 - 1;
      const a = Math.PI * 0.5 + Math.PI * Math.sign(t) * Math.pow(Math.abs(t), 1.85);
      const cs = Math.cos(a), sn = Math.sin(a);
      let x = w * Math.sign(cs) * Math.pow(Math.abs(cs), pExp);
      let z = (sn >= 0 ? dF : dB) * Math.sign(sn) * Math.pow(Math.abs(sn), pExp);
      if (z > 0) {
        const rel = faceRelief(x, y);
        const wgt = Math.pow(sn, 0.7);          // fade features toward the sides
        z += rel.dz * wgt;
        x += rel.dx * Math.abs(cs);
        // re-wrap onto the ellipse so widths stay stable
        const lim = w;
        if (Math.abs(x) > lim) x = Math.sign(x) * lim;
      }
      pos.push(x, y, z);
    }
  }
  const N = cols + 1;
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const a = r * N + c, b = r * N + c + 1, cc = (r + 1) * N + c, d = (r + 1) * N + c + 1;
      idx.push(a, cc, b, b, cc, d);
    }
  const topC = pos.length / 3; pos.push(0, y0 + 0.002, 0);
  const botC = pos.length / 3; pos.push(0, y1 - 0.002, 0);
  for (let c = 0; c < cols; c++) idx.push(topC, c, c + 1);
  const base = rows * N;
  for (let c = 0; c < cols; c++) idx.push(botC, base + c + 1, base + c);

  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

/* depth of the finished face surface at (x,y) — used to seat the eyes */
function faceSurfaceZ(x, y) {
  const w = widthAt(y), dF = faceBase(y);
  const k = clamp01(Math.abs(x) / w);
  const z0 = dF * Math.sqrt(Math.max(0.05, 1 - k * k));
  const sn = Math.sqrt(Math.max(0, 1 - k * k));
  return z0 + faceRelief(x, y).dz * Math.pow(Math.max(0.001, sn), 0.7);
}

/* ---------- facial features as thin shells hugging the face surface ------ */
/* Seat a flat patch on the face surface. (ox,oy) is the patch centre in head
   space; zBase is subtracted so the patch can live inside a group that already
   sits at that centre. */
function onFace(geo, lift, ox, oy, zBase) {
  ox = ox || 0; oy = oy || 0; zBase = zBase || 0;
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i);
    p.setXYZ(i, x, y, faceSurfaceZ(ox + x, oy + y) - zBase + lift);
  }
  geo.computeVertexNormals();
  return geo;
}
function shapeGeo(build, lift, seg, ox, oy, zBase) {
  const sh = new THREE.Shape();
  build(sh);
  return onFace(new THREE.ShapeGeometry(sh, seg || 8), lift, ox, oy, zBase);
}
/* squash a shell forward in the middle so it reads as a rounded eyeball */
function bulgeGeo(g, hw, hh, amt) {
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const X = p.getX(i) / hw, Y = p.getY(i) / hh;
    const k = 1 - X * X - Y * Y;
    if (k > 0) p.setZ(i, p.getZ(i) + amt * k);
  }
  g.computeVertexNormals();
  return g;
}

/* the nose: a stack of cross-sections/* the nose: a stack of cross-sections that rise out of the face and merge back
   into it at the edges, so it has a real ridge, tip and wings */
function noseGeo() {
  const secs = [
    // y,      halfWidth, protrusion
    [0.0330, 0.0080, 0.0012],
    [0.0245, 0.0090, 0.0042],
    [0.0120, 0.0098, 0.0086],
    [-0.0020, 0.0106, 0.0130],
    [-0.0150, 0.0120, 0.0176],
    [-0.0265, 0.0142, 0.0212],
    [-0.0350, 0.0172, 0.0222],
    [-0.0425, 0.0210, 0.0182],
    [-0.0490, 0.0220, 0.0112],
    [-0.0535, 0.0198, 0.0056],
    [-0.0570, 0.0152, 0.0020]
  ];
  const cols = 26, rows = secs.length;
  const pos = [], idx = [];
  for (let r = 0; r < rows; r++) {
    const [y, hw, prot] = secs[r];
    const base = faceBase(y);
    for (let c = 0; c <= cols; c++) {
      const u = -1.6 + 3.2 * (c / cols);
      const ax = Math.abs(u);
      const k = clamp01(ax / 1.0);
      const lift = Math.pow(Math.max(0, 1 - k * k), 1.15);
      // falloff past the wing, sinking below the face so the seam is hidden
      const sink = ax > 1 ? -0.0025 * (ax - 1) / 0.6 : 0;
      const z = base - 0.0012 + (prot + 0.0012) * lift + sink;
      pos.push(u * hw, y, z);
    }
  }
  const N = cols + 1;
  for (let r = 0; r < rows - 1; r++)
    for (let c = 0; c < cols; c++) {
      const a = r * N + c, b = r * N + c + 1, cc = (r + 1) * N + c, d = (r + 1) * N + c + 1;
      idx.push(a, cc, b, b, cc, d);
    }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

/* =========================================================================
   FACE — cel-shaded features built as thin shells lying on the skull.
   ========================================================================= */
function buildFace(mats) {
  const { browMat, lipMat, lashMat } = mats;
  const grp = new THREE.Group();

  const scleraMat = paintMat({ color: 0xe9dcc4, shadow: 0xa2907a, hi: 0xfdf7ea, amb: 0x3a3226, rampLo: 0.25, rampHi: 0.88, rim: 0.30, spec: 0.10, shine: 40 });
  const irisMat = paintMat({ color: 0x6a4a2c, shadow: 0x1a0e06, hi: 0xa87a46, amb: 0x150d07, rampLo: 0.15, rampHi: 0.88, rim: 0.22, spec: 0.30, shine: 80 });
  const pupilMat = paintMat({ color: 0x0a0604, shadow: 0x000000, hi: 0x1c1008, amb: 0x000000, rampLo: 0.2, rampHi: 0.8, rim: 0.10, spec: 0 });
  const nostrilMat = paintMat({ color: 0x45261a, shadow: 0x160a05, hi: 0x5a3220, amb: 0x0e0704, rampLo: 0.2, rampHi: 0.8, rim: 0.05, spec: 0 });
  const creaseMat = paintMat({ color: 0xa8734f, shadow: 0x8a5b3c, hi: 0xc48f68, amb: 0x2a1c12, rampLo: 0.3, rampHi: 0.9, rim: 0.1, spec: 0.05 });
  const glintMat = new THREE.MeshBasicMaterial({ color: 0xfdfbf3, fog: false });

  /* ---------------------------------------------------------- eyes */
  const eyes = [];
  for (const s of [-1, 1]) {
    const ex = s * 0.0330, ey = -0.0034, zc = faceSurfaceZ(ex, ey);
    const hw = 0.0146, ehT = 0.0058, ehB = 0.0047;
    const topY = u => ehT * (1 - Math.pow(Math.abs(u), 1.85));
    const botY = u => -ehB * (1 - Math.pow(Math.abs(u), 1.85));
    const DOME = 0.0042, HH = 0.0105, LIFT0 = 0.0008;

    const eyeGrp = new THREE.Group();
    eyeGrp.position.set(ex, ey, zc);
    const lid = new THREE.Group();
    eyeGrp.add(lid);

    const shell = (build, lift, seg, dome) => {
      let g = shapeGeo(build, lift, seg, ex, ey, zc);
      if (dome) g = bulgeGeo(g, hw, HH, dome);
      return g;
    };

    lid.add(new THREE.Mesh(shell(sh => {
      for (let i = 0; i <= 48; i++) { const u = -1 + 2 * i / 48; i ? sh.lineTo(u * hw, topY(u)) : sh.moveTo(u * hw, topY(u)); }
      for (let i = 48; i >= 0; i--) { const u = -1 + 2 * i / 48; sh.lineTo(u * hw, botY(u)); }
      sh.closePath();
    }, LIFT0, 8, DOME), scleraMat));

    const disc = (r, cx, cy, lift, mat, seg) => new THREE.Mesh(shell(sh => {
      sh.absarc(cx, cy, r, 0, Math.PI * 2, false);
    }, lift, seg || 10), mat);
    lid.add(disc(0.0050, 0, 0.0002, 0.0049, irisMat, 26));
    lid.add(disc(0.0021, 0, 0.0002, 0.0052, pupilMat, 20));
    lid.add(disc(0.00105, -0.0016, 0.0021, 0.0055, glintMat, 12));

    // upper lash line, heavier at the outer corner
    lid.add(new THREE.Mesh(shell(sh => {
      for (let i = 0; i <= 48; i++) {
        const u = -1 + 2 * i / 48, t = u * s;
        const y = topY(u) + 0.0003 + 0.0012 * (1 - u * u) + 0.0007 * Math.max(0, t);
        i ? sh.lineTo(u * hw * 1.03, y) : sh.moveTo(u * hw * 1.03, y);
      }
      for (let i = 48; i >= 0; i--) {
        const u = -1 + 2 * i / 48, t = u * s;
        const y = topY(u) - 0.0008 - 0.0005 * (1 - u * u) + 0.0007 * Math.max(0, t);
        sh.lineTo(u * hw * 1.03, y);
      }
      sh.closePath();
    }, 0.0013, 8), lashMat));

    // lower lid line
    lid.add(new THREE.Mesh(shell(sh => {
      for (let i = 0; i <= 48; i++) { const u = -1 + 2 * i / 48; const y = botY(u) - 0.0002; i ? sh.lineTo(u * hw * 0.97, y) : sh.moveTo(u * hw * 0.97, y); }
      for (let i = 48; i >= 0; i--) { const u = -1 + 2 * i / 48; sh.lineTo(u * hw * 0.97, botY(u) - 0.0011); }
      sh.closePath();
    }, 0.0012, 8), lashMat));

    // upper lid crease
    lid.add(new THREE.Mesh(shapeGeo(sh => {
      for (let i = 0; i <= 40; i++) {
        const u = -1 + 2 * i / 40;
        const y = topY(u) + 0.0030 + 0.0016 * (1 - u * u);
        i ? sh.lineTo(u * hw * 0.98, y) : sh.moveTo(u * hw * 0.98, y);
      }
      for (let i = 40; i >= 0; i--) {
        const u = -1 + 2 * i / 40;
        sh.lineTo(u * hw * 0.98, topY(u) + 0.0026 + 0.0016 * (1 - u * u));
      }
      sh.closePath();
    }, 0.0009, 6, ex, ey, zc), creaseMat));

    eyeGrp.rotation.z = s * 0.03;
    grp.add(eyeGrp);
    eyes.push(eyeGrp);
  }

  /* ---------------------------------------------------------- brows */
  for (const s of [-1, 1]) {
    const pts = [];
    for (let i = 0; i <= 18; i++) {
      const t = i / 18;
      pts.push([s * lerp(0.0120, 0.0555, t),
                lerp(0.0252, 0.0308, t) + Math.sin(t * 2.9) * 0.0024 - 0.0012 * (1 - t),
                lerp(0.0034, 0.0013, Math.pow(t, 0.9))]);
    }
    grp.add(new THREE.Mesh(shapeGeo(sh => {
      sh.moveTo(pts[0][0], pts[0][1] - pts[0][2] * 0.4);
      for (const q of pts) sh.lineTo(q[0], q[1] + q[2]);
      for (let i = pts.length - 1; i >= 0; i--) sh.lineTo(pts[i][0], pts[i][1] - pts[i][2]);
      sh.closePath();
    }, 0.0009, 8), browMat));
  }

  /* ---------------------------------------------------------- lips */
  const cy = -0.0722;
  grp.add(new THREE.Mesh(shapeGeo(sh => {
    for (let i = 0; i <= 40; i++) {
      const u = -1 + 2 * i / 40;
      const y = cy + 0.0062 * (1 - Math.pow(Math.abs(u), 1.6)) - 0.0014 * Math.exp(-Math.pow(u / 0.16, 2));
      i ? sh.lineTo(u * 0.0226, y) : sh.moveTo(u * 0.0226, y);
    }
    for (let i = 40; i >= 0; i--) { const u = -1 + 2 * i / 40; sh.lineTo(u * 0.0226, cy + 0.0004 * (1 - u * u)); }
    sh.closePath();
  }, 0.0009, 4), lipMat));
  grp.add(new THREE.Mesh(shapeGeo(sh => {
    for (let i = 0; i <= 40; i++) {
      const u = -1 + 2 * i / 40;
      const y = cy - 0.0078 * (1 - Math.pow(Math.abs(u), 1.7));
      i ? sh.lineTo(u * 0.0208, y) : sh.moveTo(u * 0.0208, y);
    }
    for (let i = 40; i >= 0; i--) { const u = -1 + 2 * i / 40; sh.lineTo(u * 0.0208, cy - 0.0004 * (1 - u * u)); }
    sh.closePath();
  }, 0.0009, 4), lipMat));
  grp.add(new THREE.Mesh(shapeGeo(sh => {
    for (let i = 0; i <= 40; i++) {
      const u = -1 + 2 * i / 40;
      const y = cy + 0.0002 * (1 - u * u) - 0.0011 * Math.exp(-Math.pow(u / 0.55, 2));
      i ? sh.lineTo(u * 0.0224, y + 0.0008) : sh.moveTo(u * 0.0224, y + 0.0008);
    }
    for (let i = 40; i >= 0; i--) {
      const u = -1 + 2 * i / 40;
      const y = cy + 0.0002 * (1 - u * u) - 0.0011 * Math.exp(-Math.pow(u / 0.55, 2));
      sh.lineTo(u * 0.0224, y - 0.0008);
    }
    sh.closePath();
  }, 0.0013, 4), lashMat));

  /* -------------------------------------------------------- nostrils */
  for (const s of [-1, 1]) {
    const nx = s * 0.0106, ny = -0.0516;
    grp.add(new THREE.Mesh(shapeGeo(sh => {
      sh.absellipse(0, 0, 0.0030, 0.0018, 0, Math.PI * 2, false, 0);
    }, 0.0074, 8, nx, ny, 0), nostrilMat));
  }

  grp.userData.eyes = eyes;
  return grp;
}

/* ------------------------------------------------------------------ head */
function buildHead(mats) {
  const { skinMat, lashMat } = mats;
  const head = new THREE.Group();

  const skull = new THREE.Mesh(buildSkullGeo(230, 260, 0.94), skinMat);
  head.add(skull);

  const nose = new THREE.Mesh(noseGeo(), skinMat);
  head.add(nose);
  for (const s of [-1, 1]) {
    const ala = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), skinMat);
    ala.scale.set(0.0069, 0.0056, 0.0063);
    ala.position.set(s * 0.0148, -0.0448, faceBase(-0.0448) + 0.0068);
    head.add(ala);
  }

  /* ---- ears ------------------------------------------------------------ */
  const earX = widthAt(-0.0070);
  for (const s of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 16), skinMat);
    ear.scale.set(0.0036, 0.0182, 0.0118);
    ear.position.set(s * (earX - 0.0040), -0.0070, -0.0200);
    ear.rotation.set(0.05, s * 0.20, s * -0.05);
    head.add(ear);
    const helix = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 14), skinMat);
    helix.scale.set(0.0030, 0.0152, 0.0096);
    helix.position.set(s * (earX - 0.0052), -0.0050, -0.0202);
    helix.rotation.set(0.05, s * 0.20, s * -0.05);
    head.add(helix);
    const lobe = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 12), skinMat);
    lobe.scale.set(0.0034, 0.0056, 0.0068);
    lobe.position.set(s * (earX - 0.0042), -0.0206, -0.0186);
    head.add(lobe);
    const conch = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 10), lashMat);
    conch.scale.set(0.0014, 0.0052, 0.0034);
    conch.position.set(s * (earX - 0.0050), -0.0074, -0.0182);
    head.add(conch);
  }

  /* ---- neck stub, welded under the jaw --------------------------------- */
  const neckTop = new THREE.Mesh(new THREE.CylinderGeometry(0.0430, 0.0505, 0.200, 26, 3), skinMat);
  neckTop.scale.set(0.94, 1, 0.98);
  neckTop.position.set(0, -0.172, -0.0180);
  head.add(neckTop);

  const feats = buildFace(mats);
  head.add(feats);
  const face = { mesh: feats, blink: -1 };
  face.setBlink = b => {
    const q = clamp01(b);
    for (const e of feats.userData.eyes) {
      e.children[0].scale.y = 1 - q * 0.94;
      e.children[0].position.y = q * 0.0004;
    }
  };
  head.userData.face = face;
  return { head, skull, face, eyes: [face], EYE: null };
}

/* ---------------------------------------------------------------- hair */
function buildHair(mats) {
  const { hairMat } = mats;
  const grp = new THREE.Group();
  const hair2 = hairMat.clone();
  hair2.uniforms.uColor.value.setHex(0x463327);
  hair2.uniforms.uShadow.value.setHex(0x1c1310);
  hair2.uniforms.uHi.value.setHex(0x7a6656);
  hair2.side = THREE.DoubleSide;
  const Y_TOP = 0.1215;

  // the hairline, with a lazy side-sweep across the forehead
  const hairline = a => {
    const sn = Math.sin(a), cs = Math.cos(a);
    const front = Math.pow(Math.max(0, sn), 1.7);
    return 0.0660 * front + 0.0345 * (1 - Math.abs(sn)) - 0.0555 * Math.pow(Math.max(0, -sn), 1.15)
         + 0.0085 * front * cs;
  };
  // point on the hair mass: t = 0 at the hairline, 1 at the crown
  const P = (a, t, lift) => {
    const y = lerp(hairline(a), Y_TOP, Math.pow(clamp01(t), 0.80));
    const w = widthAt(y), dB = depthBackAt(y), dF = faceBase(y);
    const cs = Math.cos(a), sn = Math.sin(a);
    const grow = 1.030 + 0.052 * Math.sin(Math.PI * clamp01(t)) + 0.020 * clamp01(-sn);
    let x = w * Math.sign(cs) * Math.pow(Math.abs(cs), 0.94) * grow;
    let z = (sn >= 0 ? dF : dB) * Math.sign(sn) * Math.pow(Math.abs(sn), 0.94) * grow;
    if (z > 0) z += 0.0035;
    const v = new THREE.Vector3(x, y + 0.013 * Math.sin(Math.PI * clamp01(t)), z);
    if (lift) {
      const n = new THREE.Vector3(x, (y - 0.016) * 0.50, z).normalize();
      v.addScaledVector(n, lift);
    }
    return v;
  };

  /* ---- the mass ---- */
  const ROWS = 30, COLS = 108, pos = [], idx = [];
  for (let r = 0; r <= ROWS; r++) {
    const t = r / ROWS;
    for (let c = 0; c <= COLS; c++) {
      const a = (c / COLS) * Math.PI * 2;
      const q = P(a, t, 0);
      pos.push(q.x, q.y, q.z);
    }
  }
  const N = COLS + 1;
  for (let r = 0; r < ROWS; r++)
    for (let c = 0; c < COLS; c++) {
      const A = r * N + c, B = r * N + c + 1, C = (r + 1) * N + c, D = (r + 1) * N + c + 1;
      idx.push(A, C, B, B, C, D);
    }
  const apex = pos.length / 3;
  pos.push(0, Y_TOP + 0.0030, -0.010);
  for (let c = 0; c < COLS; c++) idx.push(apex, ROWS * N + c, ROWS * N + c + 1);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  grp.add(new THREE.Mesh(g, hairMat));

  /* ---- combed ribbons lying on the mass: the strand reading ---- */
  const ribbon = (a0, da, t0, t1, lift, mat) => {
    const SEG = 9, sp = [], si = [];
    for (let i = 0; i <= SEG; i++) {
      const f = i / SEG;
      const t = t0 + (t1 - t0) * f;
      const taper = Math.min(1, 0.55 + 2.0 * f) * (1 - 0.55 * Math.pow(f, 3.0));
      const w = da * taper;
      const fade = Math.min(1, f * 4, (1 - f) * 4);
      const pA = P(a0 - w, t, lift * fade + 0.0004);
      const pB = P(a0 + w, t, lift * fade + 0.0004);
      sp.push(pA.x, pA.y, pA.z, pB.x, pB.y, pB.z);
    }
    for (let i = 0; i < SEG; i++) { const k = i * 2; si.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
    sg.setIndex(si);
    sg.computeVertexNormals();
    return new THREE.Mesh(sg, mat);
  };
  for (let i = 0; i < 44; i++) {
    const a0 = (i / 44) * Math.PI * 2 + 0.04;
    const j = Math.sin(i * 7.31) * 0.5 + 0.5;
    grp.add(ribbon(a0, 0.058 + 0.014 * j, 0.34 + 0.05 * j, 0.94 + 0.04 * j, 0.0026, hair2));
  }
  for (let i = 0; i < 40; i++) {
    const a0 = ((i + 0.5) / 40) * Math.PI * 2;
    const j = Math.sin(i * 3.71) * 0.5 + 0.5;
    grp.add(ribbon(a0, 0.038, 0.30 + 0.04 * j, 0.97, 0.0012, hairMat));
  }

  /* ---- a fringe shell hanging over the forehead, hugging the mass ---- */
  const FR = 14, FC = 84;
  const fpos = [], fidx = [];
  for (let r = 0; r <= FR; r++) {
    const f = r / FR;                       // 0 at the fringe edge, 1 where it melts in
    for (let c = 0; c <= FC; c++) {
      const a = (c / FC) * Math.PI * 2;
      const cs = Math.cos(a), sn = Math.sin(a);
      const front = Math.pow(Math.max(0, sn), 1.2);
      // the fringe hangs lower on the character's right, and only at the front
      const hang = front * (0.0175 + 0.0075 * cs);
      const t = 0.0 + f * 0.46;
      const lift = 0.0062 * Math.pow(1 - f, 1.4) * (0.35 + 0.65 * front);
      const q = P(a, t, lift);
      // drag the fringe edge down
      q.y -= hang * Math.pow(1 - f, 1.8);
      fpos.push(q.x, q.y, q.z);
    }
  }
  const FC1 = FC + 1;
  for (let r = 0; r < FR; r++)
    for (let c = 0; c < FC; c++) {
      const A = r * FC1 + c, B = r * FC1 + c + 1, C = (r + 1) * FC1 + c, D = (r + 1) * FC1 + c + 1;
      fidx.push(A, C, B, B, C, D);
    }
  const fg = new THREE.BufferGeometry();
  fg.setAttribute('position', new THREE.Float32BufferAttribute(fpos, 3));
  fg.setIndex(fidx);
  fg.computeVertexNormals();
  grp.add(new THREE.Mesh(fg, hairMat));

  /* ---- sideburns in front of the ears ---- */
  for (const s of [-1, 1]) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), hairMat);
    m.position.set(s * 0.0720, 0.0450, -0.0055);
    m.scale.set(0.0092, 0.0165, 0.0140);
    m.rotation.set(0.05, s * 0.30, s * -0.08);
    grp.add(m);
  }
  return grp;
}
