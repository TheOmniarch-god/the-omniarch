/* =========================================================================
   GU ZHEN REN — the man. Sculpted head, suit, hands, hair, blinking.
   Built in metres; head sits at the origin of its own group, face toward +Z.
   ========================================================================= */

const SKIN = {
  base: 0xd8a887, shadow: 0x8e5a44, hi: 0xf3d2b4,
  rim: 0xffd9b8, amb: 0x3a2c26
};

/* --------------------------------------------------------------- head shape */
function sculptHeadGeo() {
  const g = new THREE.SphereGeometry(1, 44, 34);
  const pos = g.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i).normalize();
    let x = v.x, y = v.y, z = v.z;

    // --- base skull ellipsoid -------------------------------------------
    let X = x * 0.080, Y = y * 0.114, Z = z * 0.093;

    // flatten the back of the skull a touch
    if (Z < 0) Z *= 0.96;
    // flatten the face plane slightly
    if (Z > 0) Z *= 0.99 - 0.06 * Math.pow(Math.max(0, Math.abs(x) - 0.35), 2);

    const ty = clamp01((0.02 - Y) / 0.20);           // 0 at mid-face, 1 at chin
    // --- jaw taper + chin -------------------------------------------------
    if (Y < 0.02) {
      const t = ty;
      X *= 1 - 0.34 * t * t;
      Z *= 1 - 0.05 * t;
      // chin block: push the front-bottom forward
      const chin = Math.exp(-Math.pow(x / 0.30, 2)) * Math.exp(-Math.pow((Y + 0.075) / 0.045, 2)) * Math.max(0, z);
      Z += chin * 0.016;
      Y -= chin * 0.006;
      // jaw angle
      const jaw = Math.exp(-Math.pow((Math.abs(x) - 0.62) / 0.26, 2)) * Math.exp(-Math.pow((Y + 0.055) / 0.06, 2));
      Z -= jaw * 0.004;
    }
    // --- cheekbones -------------------------------------------------------
    const chk = Math.exp(-Math.pow((Math.abs(x) - 0.58) / 0.22, 2)) * Math.exp(-Math.pow((Y - 0.005) / 0.10, 2)) * Math.max(0, z);
    X += Math.sign(x) * chk * 0.004;
    Z += chk * 0.006;
    // --- brow ridge -------------------------------------------------------
    const brow = Math.exp(-Math.pow((Y - 0.045) / 0.028, 2)) * Math.exp(-Math.pow(x / 0.62, 2)) * Math.max(0, z);
    Z += brow * 0.011;
    Y += brow * 0.002;
    // --- eye sockets (concave) -------------------------------------------
    const sock = Math.exp(-Math.pow((Math.abs(x) - 0.40) / 0.20, 2)) * Math.exp(-Math.pow((Y - 0.012) / 0.035, 2)) * Math.max(0, z);
    Z -= sock * 0.013;
    // --- temples slightly hollow -----------------------------------------
    const tmp = Math.exp(-Math.pow((Math.abs(x) - 0.86) / 0.18, 2)) * Math.exp(-Math.pow((Y - 0.06) / 0.09, 2));
    X -= Math.sign(x) * tmp * 0.003;
    // --- nose ridge -------------------------------------------------------
    const noseY = clamp01((0.055 - Y) / 0.105);          // 0 bridge .. 1 tip
    const noseX = Math.exp(-Math.pow(x / (0.10 + 0.06 * noseY), 2));
    const noseProfile = Math.sin(Math.min(1, noseY) * Math.PI * 0.92);
    const nose = noseX * noseProfile * Math.max(0, z) * (z > 0 ? 1 : 0);
    Z += nose * (0.004 + 0.019 * Math.pow(noseY, 1.4));
    X += Math.sign(x) * noseX * noseProfile * noseY * 0.006 * (Math.abs(x) > 0.02 ? 1 : 0.2);
    // nostril wings
    const wing = Math.exp(-Math.pow((Math.abs(x) - 0.115) / 0.045, 2)) * Math.exp(-Math.pow((Y + 0.043) / 0.022, 2)) * Math.max(0, z);
    Z += wing * 0.008;
    X += Math.sign(x) * wing * 0.006;
    // --- mouth ------------------------------------------------------------
    const lips = Math.exp(-Math.pow((Y + 0.062) / 0.020, 2)) * Math.exp(-Math.pow(x / 0.28, 2)) * Math.max(0, z);
    Z += lips * 0.009;
    // philtrum dip
    const phil = Math.exp(-Math.pow(x / 0.05, 2)) * Math.exp(-Math.pow((Y + 0.038) / 0.016, 2)) * Math.max(0, z);
    Z -= phil * 0.004;
    // --- neck socket ------------------------------------------------------
    const nec = Math.exp(-Math.pow(Y / 0.055, 2)) * 0;
    Y += nec;

    pos.setXYZ(i, X, Y, Z);
  }
  g.computeVertexNormals();
  g.computeBoundingSphere();
  return g;
}

/* ------------------------------------------------------------------- eyes */
function eyeTexture() {
  const s = 256, c = cnv(s, s), x = c.getContext('2d');
  x.fillStyle = '#f6f1ea'; x.fillRect(0, 0, s, s);
  // veins
  for (let i = 0; i < 40; i++) {
    x.strokeStyle = 'rgba(190,120,110,' + rand(0.05, 0.16) + ')';
    x.lineWidth = rand(0.5, 1.6);
    x.beginPath(); x.moveTo(rand(0, s), rand(0, s));
    x.lineTo(rand(0, s), rand(0, s)); x.stroke();
  }
  const cx = s / 2, cy = s / 2;
  const iris = x.createRadialGradient(cx, cy, 8, cx, cy, 52);
  iris.addColorStop(0, '#3a2418'); iris.addColorStop(0.55, '#5a3a22');
  iris.addColorStop(0.86, '#2a170e'); iris.addColorStop(1, '#1a0f08');
  x.fillStyle = iris; x.beginPath(); x.arc(cx, cy, 52, 0, 6.3); x.fill();
  // striations
  for (let i = 0; i < 120; i++) {
    const a = Math.random() * 6.3, r0 = rand(16, 30), r1 = rand(40, 50);
    x.strokeStyle = 'rgba(150,105,60,' + rand(0.08, 0.3) + ')';
    x.lineWidth = rand(0.6, 1.8);
    x.beginPath(); x.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
    x.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); x.stroke();
  }
  x.fillStyle = '#0b0705'; x.beginPath(); x.arc(cx, cy, 19, 0, 6.3); x.fill();
  const gl = x.createRadialGradient(cx - 14, cy - 16, 0, cx - 14, cy - 16, 22);
  gl.addColorStop(0, 'rgba(255,255,255,0.9)'); gl.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = gl; x.beginPath(); x.arc(cx - 14, cy - 16, 22, 0, 6.3); x.fill();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/* ------------------------------------------------------------------- hair */
function makeHair(headR, mats) {
  const grp = new THREE.Group();
  const hairMat = paintMat({
    color: 0x2a1e1a, shadow: 0x120c0a, hi: 0x6b4f42, rimColor: 0x9d8672,
    amb: 0x1a1412, rampLo: 0.30, rampHi: 0.72, rim: 0.55, spec: 0.05, shine: 12,
    tex: TEX.hair, texAmt: 0.55
  });
  // main mass: a shell slightly larger than the skull, cut above the brow
  const shell = new THREE.SphereGeometry(1, 32, 26, 0, Math.PI * 2, 0, Math.PI * 0.40);
  const pos = shell.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i).normalize();
    // volume, fuller at the back and top
    const vol = 1 + 0.10 * clamp01(v.y) + 0.06 * clamp01(-v.z);
    let X = v.x * 0.086 * vol;
    let Y = v.y * 0.121 * vol;
    let Z = v.z * 0.101 * vol - 0.006;
    // sweep the silhouette: higher on the left, lower on the right
    Y += X * 0.16;
    Y -= clamp01(-v.z) * 0.02;
    // pull the front edge back so the forehead is open
    if (v.z > 0.35) Z -= 0.012 * (v.z - 0.35);
    pos.setXYZ(i, X, Y, Z);
  }
  shell.computeVertexNormals();
  const cap = new THREE.Mesh(shell, hairMat);
  cap.position.y = 0.004;
  grp.add(cap);

  // back mass, filling the nape
  {
    const bm = new THREE.SphereGeometry(1, 22, 18, 0, Math.PI * 2, Math.PI * 0.35, Math.PI * 0.42);
    const bp = bm.attributes.position, bv = new THREE.Vector3();
    for (let i = 0; i < bp.count; i++) {
      bv.fromBufferAttribute(bp, i).normalize();
      bp.setXYZ(i, bv.x * 0.085, bv.y * 0.108 - 0.012, bv.z * 0.098 - 0.012);
    }
    bm.computeVertexNormals();
    grp.add(new THREE.Mesh(bm, hairMat));
  }

  // swept fringe: overlapping clumps across the forehead
  for (let i = 0; i < 9; i++) {
    const t = i / 8;
    const g2 = new THREE.SphereGeometry(1, 14, 10);
    const p2 = g2.attributes.position, v2 = new THREE.Vector3();
    for (let k = 0; k < p2.count; k++) {
      v2.fromBufferAttribute(p2, k).normalize();
      p2.setXYZ(k, v2.x * 0.030 * (1 + 0.4 * Math.abs(v2.z)), v2.y * 0.016, v2.z * 0.052);
    }
    g2.computeVertexNormals();
    const clump = new THREE.Mesh(g2, hairMat);
    const ang = -1.15 + t * 1.35;
    clump.position.set(
      Math.sin(ang) * 0.062,
      0.090 - Math.abs(t - 0.35) * 0.020,
      Math.cos(ang) * 0.056 + 0.026);
    clump.rotation.set(rand(-0.1, 0.12), ang * 1.1 + 0.35, -0.55 + t * 0.35 + rand(-0.1, 0.1));
    clump.scale.set(1 + Math.random() * 0.35, 1, 1);
    grp.add(clump);
  }
  // a couple of long strands falling at the temple
  for (const s of [-1, 1]) {
    const sg = new THREE.SphereGeometry(1, 10, 8);
    const p3 = sg.attributes.position, v3 = new THREE.Vector3();
    for (let k = 0; k < p3.count; k++) {
      v3.fromBufferAttribute(p3, k).normalize();
      p3.setXYZ(k, v3.x * 0.012, v3.y * 0.045, v3.z * 0.018);
    }
    sg.computeVertexNormals();
    const st = new THREE.Mesh(sg, hairMat);
    st.position.set(s * 0.078, 0.03, 0.028);
    st.rotation.z = s * 0.25; st.rotation.x = -0.2;
    grp.add(st);
  }
  return grp;
}

/* ------------------------------------------------------------------ build */
function buildGu() {
  const G = {};

  const skinMat = paintMat({
    color: SKIN.base, shadow: SKIN.shadow, hi: SKIN.hi, rimColor: 0xffd0aa,
    amb: SKIN.amb, rampLo: 0.26, rampHi: 0.72, rim: 0.55, spec: 0.06, shine: 22,
    tex: TEX.skin, texAmt: 0.30
  });
  const lipMat = paintMat({
    color: 0xa8635a, shadow: 0x6d3730, hi: 0xd08a7c, rimColor: 0xffc0a0,
    amb: 0x2c1a16, rampLo: 0.28, rampHi: 0.72, rim: 0.4, spec: 0.12, shine: 40
  });
  const browMat = paintMat({
    color: 0x2c1d16, shadow: 0x140c08, hi: 0x5a3d2e, amb: 0x140e0a, rampLo: 0.3, rampHi: 0.7, rim: 0.3
  });
  const scleraMat = new THREE.MeshBasicMaterial({ map: eyeTexture(), fog: false });
  const lidMat = paintMat({
    color: 0xc99a7c, shadow: 0x7d4c3a, hi: 0xe8c0a0, amb: 0x2a1c18,
    rampLo: 0.26, rampHi: 0.72, rim: 0.5, spec: 0.05, shine: 30
  });

  /* ---- head ---------------------------------------------------------- */
  const lashMat = paintMat({
    color: 0x241611, shadow: 0x0c0705, hi: 0x4a332a, amb: 0x120c09,
    rampLo: 0.3, rampHi: 0.7, rim: 0.25
  });
  const hairMat = paintMat({
    color: 0x2a1e17, shadow: 0x0b0705, hi: 0x584436, rimColor: 0x9a8a76,
    amb: 0x181210, rampLo: 0.30, rampHi: 0.70, rim: 0.55, spec: 0.14, shine: 34,
    tex: TEX.hair, texAmt: 0.55
  });
  const H = buildHead({ skinMat, browMat, lipMat, lashMat, hairMat });
  const head = H.head;
  head.add(buildHair({ hairMat }));
  G.head = head;
  G.skull = H.skull;
  G.eyes = H.eyes;


  /* ---- body ---------------------------------------------------------- */
  const body = new THREE.Group();
  const suitMat = paintMat({
    color: 0xa8845c, shadow: 0x5d432a, hi: 0xd0b184, rimColor: 0xe8d0a8,
    amb: 0x2c241c, rampLo: 0.24, rampHi: 0.70, rim: 0.5, spec: 0.05, shine: 14,
    tex: TEX.fabric, texAmt: 0.35
  });
  const suitDark = paintMat({
    color: 0x8a6a46, shadow: 0x45301c, hi: 0xb08e62, rimColor: 0xe0c69c,
    amb: 0x282018, rampLo: 0.24, rampHi: 0.70, rim: 0.45, spec: 0.04, shine: 12,
    tex: TEX.fabric, texAmt: 0.35
  });
  const shirtMat = paintMat({
    color: 0xdfe4e0, shadow: 0x93a0a4, hi: 0xffffff, rimColor: 0xdff0ff,
    amb: 0x2a2e30, rampLo: 0.26, rampHi: 0.74, rim: 0.4, spec: 0.08, shine: 18,
    tex: TEX.fabric, texAmt: 0.25
  });
  const vestMat = paintMat({
    color: 0x2b2c2a, shadow: 0x111212, hi: 0x4e5150, rimColor: 0x8fa2ab,
    amb: 0x1a1c1d, rampLo: 0.28, rampHi: 0.72, rim: 0.45, spec: 0.08, shine: 20,
    tex: TEX.fabric, texAmt: 0.3
  });

  const torso = new THREE.Group();

  /* ---- jacket body: lofted rings, hips at y=0, shoulders near y=0.45 -- */
  const P = 0.80;
  const JACKET = [
    { y: -0.195, w: 0.055, d: 0.050, z: 0.000 },
    { y: -0.170, w: 0.150, d: 0.128, z: 0.004 },
    { y: -0.120, w: 0.204, d: 0.172, z: 0.008 },
    { y: -0.050, w: 0.196, d: 0.162, z: 0.006 },
    { y:  0.020, w: 0.182, d: 0.150, z: 0.003 },
    { y:  0.095, w: 0.172, d: 0.143, z: 0.000 },
    { y:  0.170, w: 0.172, d: 0.143, z: 0.000 },
    { y:  0.250, w: 0.181, d: 0.147, z: 0.002 },
    { y:  0.330, w: 0.197, d: 0.150, z: 0.004 },
    { y:  0.400, w: 0.214, d: 0.148, z: 0.003 },
    { y:  0.450, w: 0.220, d: 0.139, z: 0.000 },
    { y:  0.487, w: 0.194, d: 0.116, z: -0.002 },
    { y:  0.512, w: 0.120, d: 0.082, z: -0.004 },
    { y:  0.525, w: 0.062, d: 0.058, z: -0.004 }
  ];
  function profileAt(y) {
    if (y <= JACKET[0].y) return JACKET[0];
    for (let i = 0; i < JACKET.length - 1; i++) {
      const a = JACKET[i], b = JACKET[i + 1];
      if (y <= b.y) {
        const t = (y - a.y) / (b.y - a.y);
        return { w: lerp(a.w, b.w, t), d: lerp(a.d, b.d, t), z: lerp(a.z, b.z, t), p: P };
      }
    }
    return JACKET[JACKET.length - 1];
  }
  const jacket = new THREE.Mesh(loftSections(JACKET.map(s => ({ ...s, p: P })), { n: 44 }), suitMat);
  torso.add(jacket);

  /* ---- tailors: vest, shirt V, lapels — all shells hugging the body ---- */
  const FRONT = Math.PI / 2;
  const shirtHalf = y => clamp01((y - 0.075) / 0.44) * 0.075 + clamp01((y - 0.075) / 0.44) * 0.0 + 0.02 + Math.pow(clamp01((y - 0.075) / 0.44), 0.85) * 0.60;

  const vest = new THREE.Mesh(shellFromProfile(0.005, 0.505, 16, y => profileAt(y),
    () => [FRONT - 1.12, FRONT + 1.12], 0.004, 20), vestMat);
  torso.add(vest);

  const shirt = new THREE.Mesh(shellFromProfile(0.075, 0.525, 16, y => profileAt(y),
    (t, y) => [FRONT - shirtHalf(y), FRONT + shirtHalf(y)], 0.009, 16), shirtMat);
  torso.add(shirt);

  for (const s of [-1, 1]) {
    const lap = new THREE.Mesh(shellFromProfile(0.075, 0.500, 16, y => profileAt(y),
      (t, y) => {
        const inner = shirtHalf(y) + 0.045;
        const outer = Math.min(inner + 0.60, 1.22);
        return s > 0 ? [FRONT + inner, FRONT + outer] : [FRONT - outer, FRONT - inner];
      }, 0.014, 12), suitDark);
    torso.add(lap);
  }

  // collar band around the neck, sitting on the jacket top
  const collar = new THREE.Mesh(shellFromProfile(0.500, 0.545, 4, y => profileAt(y),
    () => [FRONT - 1.35, FRONT + 1.35], 0.012, 18), suitDark);
  torso.add(collar);

  // buttons
  for (let i = 0; i < 2; i++) {
    const by = 0.055 + i * 0.085;
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.0072, 10, 8), suitDark);
    b.position.set(0, by, profileAt(by).d + 0.016);
    torso.add(b);
  }
  // pocket flaps
  for (const s of [-1, 1]) {
    const f = new THREE.Mesh(new THREE.BoxGeometry(0.058, 0.014, 0.010), suitDark);
    f.position.set(s * 0.105, 0.045, 0.135);
    f.rotation.y = s * -0.35;
    torso.add(f);
  }

  // shirt collar standing around the neck, hiding the head/torso join
  {
    const bandMat = shirtMat;
    const shirtCollar = new THREE.Mesh(new THREE.CylinderGeometry(0.0455, 0.0505, 0.028, 26, 1, true), bandMat);
    shirtCollar.material = bandMat.clone();
    shirtCollar.material.side = THREE.DoubleSide;
    shirtCollar.position.set(0, 0.607, -0.012);
    shirtCollar.scale.set(0.97, 1, 1.02);
    torso.add(shirtCollar);
    const jacketCollar = new THREE.Mesh(new THREE.CylinderGeometry(0.0510, 0.0590, 0.034, 26, 1, true), suitDark.clone());
    jacketCollar.material.side = THREE.DoubleSide;
    jacketCollar.position.set(0, 0.588, -0.012);
    jacketCollar.scale.set(1.0, 1, 1.03);
    torso.add(jacketCollar);
  }

  /* ---- neck + head mount ---------------------------------------------- */
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.046, 0.115, 22), skinMat);
  neck.position.set(0, 0.518, -0.012);
  torso.add(neck);

  const headMount = new THREE.Group();
  headMount.position.set(0, 0.685, 0.012);
  headMount.scale.setScalar(1.0);
  headMount.add(head);
  torso.add(headMount);

  G.torso = torso;
  G.headMount = headMount;
  for (const m of [suitDark, shirtMat, vestMat]) m.side = THREE.DoubleSide;
  G.mats = { skinMat, suitMat, suitDark, shirtMat, vestMat, lipMat, browMat, lidMat };

  /* ---- arms ------------------------------------------------------------ */
  function makeArm(side) {
    const arm = new THREE.Group();
    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.050, 0.185, 10, 16), suitMat);
    upper.position.y = -0.145;
    const joint = new THREE.Group();
    joint.add(upper);
    const fore = new THREE.Group();
    const foreMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.043, 0.175, 10, 16), suitMat);
    foreMesh.position.y = -0.105;
    fore.add(foreMesh);
    const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.047, 0.047, 0.026, 16), shirtMat);
    cuff.position.y = -0.205;
    fore.add(cuff);
    const hand = makeHand(side, skinMat);
    hand.position.y = -0.228;
    fore.add(hand);
    fore.position.y = -0.265;
    joint.add(fore);
    arm.add(joint);
    arm.userData = { joint, fore, hand };
    return arm;
  }
  function makeHand(side, mat) {
    const h = new THREE.Group();
    const palm = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), mat);
    palm.scale.set(0.030, 0.040, 0.017);
    h.add(palm);
    for (let f = 0; f < 4; f++) {
      const fin = new THREE.Mesh(new THREE.CapsuleGeometry(0.0066, 0.034, 5, 8), mat);
      fin.position.set((f - 1.5) * 0.0138, -0.036 - Math.abs(f - 1.5) * 0.004, 0.001);
      fin.rotation.z = (f - 1.5) * 0.09;
      fin.rotation.x = 0.18 + Math.abs(f - 1.5) * 0.06;
      h.add(fin);
    }
    const thumb = new THREE.Mesh(new THREE.CapsuleGeometry(0.008, 0.028, 5, 8), mat);
    thumb.position.set(side * -0.028, -0.012, 0.010);
    thumb.rotation.z = side * 0.85; thumb.rotation.x = -0.55;
    h.add(thumb);
    return h;
  }
  G.armL = makeArm(-1); G.armR = makeArm(1);
  G.armL.position.set(-0.198, 0.437, 0.004);
  G.armR.position.set(0.198, 0.437, 0.004);
  torso.add(G.armL, G.armR);

  body.add(torso);
  G.body = body;

  /* ---- legs (seated, feet on the floor) -------------------------------- */
  const legs = new THREE.Group();
  const shoeMat = paintMat({
    color: 0x241a14, shadow: 0x0a0705, hi: 0x50382a, amb: 0x161010,
    rampLo: 0.30, rampHi: 0.70, rim: 0.5, spec: 0.20, shine: 44, tex: TEX.leather, texAmt: 0.45
  });
  for (const s of [-1, 1]) {
    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.076, 0.235, 10, 18), suitDark);
    thigh.rotation.x = Math.PI / 2;
    thigh.position.set(s * 0.098, -0.045, 0.175);
    legs.add(thigh);
    const shin = new THREE.Group();
    const shinMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.060, 0.285, 10, 18), suitDark);
    shinMesh.position.y = -0.175;
    shin.add(shinMesh);
    const shoe = new THREE.Group();
    const shoeBody = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.075, 6, 14), shoeMat);
    shoeBody.rotation.x = Math.PI / 2;
    shoeBody.scale.set(1.05, 1.0, 1.0);
    shoeBody.position.set(0, 0.028, 0.035);
    shoe.add(shoeBody);
    const toe = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 12), shoeMat);
    toe.scale.set(0.048, 0.032, 0.055);
    toe.position.set(0, 0.022, 0.085);
    shoe.add(toe);
    shoe.position.set(0, -0.345, 0.01);
    shin.add(shoe);
    shin.position.set(s * 0.098, -0.045, 0.335);
    legs.add(shin);
  }
  body.add(legs);
  G.legs = legs;

  /* ---- pose helper ---------------------------------------------------- */
  G.pose = function (p) {
    const d = p || {};
    // arms: side, elbow bend, forward swing
    const setArm = (arm, side, opts) => {
      arm.rotation.set(opts.x || 0, opts.y || 0, opts.z || 0);
      arm.userData.fore.rotation.set(opts.fx || 0, 0, opts.fz || 0);
    };
    setArm(G.armL, -1, d.armL || { z: 0.18, fx: -0.35 });
    setArm(G.armR, 1, d.armR || { z: -0.18, fx: -0.35 });
    G.headMount.rotation.set(d.headX || 0, d.headY || 0, d.headZ || 0);
    G.torso.rotation.x = d.torsoX || 0;
    if (d.legRot !== undefined) G.legs.rotation.x = d.legRot;
  };
  G.pose({});

  return G;
}

/* --------------------------------------------------------- character anim */
function animateGu(G, t, opts) {
  const o = opts || {};
  const breathe = Math.sin(t * (o.breathSpeed || 1.15) + (o.phase || 0));
  G.torso.position.y = breathe * 0.004;
  G.torso.scale.set(1, 1 + breathe * 0.004, 1);
  G.headMount.position.y = 0.45 + breathe * 0.0025;
  if (o.headTurn !== undefined) G.headMount.rotation.y = o.headTurn + Math.sin(t * 0.31) * 0.02;
  if (o.headTilt !== undefined) G.headMount.rotation.z = o.headTilt + Math.sin(t * 0.24) * 0.012;
  if (o.headNod !== undefined) G.headMount.rotation.x = o.headNod + Math.sin(t * 0.19) * 0.01;

  // blink
  const bt = (t * 0.37 + 11.3) % 4.2;
  let blink = 0;
  if (bt < 0.13) blink = Math.sin(bt / 0.13 * Math.PI);
  if (o.blink !== undefined) blink = Math.max(blink, o.blink);
  for (const e of G.eyes) {
    e.up.rotation.x = -0.15 - blink * 1.15;
    e.lo.rotation.x = 0.22 + blink * 0.25;
  }
  // eyes drift
  if (o.eyeX !== undefined) for (const e of G.eyes) e.ball.rotation.y = o.eyeX;
  return blink;
}
