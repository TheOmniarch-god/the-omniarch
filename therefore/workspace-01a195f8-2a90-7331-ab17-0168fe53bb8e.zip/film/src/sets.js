/* =========================================================================
   SETS — the study (hero set), the desk, the clinic, the shelf, the corridor.
   ========================================================================= */

function applyLighting(root, cfg) {
  const seen = new Set();
  root.traverse(o => {
    if (!o.material) return;
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    for (const m of mats) {
      if (!m.userData || m.userData.kind !== 'paint' || seen.has(m.uuid)) continue;
      seen.add(m.uuid);
      if (cfg.keyDir) m.uniforms.uKeyDir.value.copy(cfg.keyDir);
      if (cfg.keyCol) m.uniforms.uKeyCol.value.copy(cfg.keyCol);
      if (cfg.fillDir) m.uniforms.uFillDir.value.copy(cfg.fillDir);
      if (cfg.fillCol) m.uniforms.uFillCol.value.copy(cfg.fillCol);
      if (cfg.amb) m.uniforms.uAmb.value.copy(cfg.amb);
      if (cfg.rimC) m.uniforms.uRimC.value.copy(cfg.rimC);
    }
  });
}

/* ---------------------------------------------------------------- plants */
function leafGeo(len, wid, bend) {
  const seg = 10;
  const pos = [], uv = [], idx = [];
  for (let i = 0; i <= seg; i++) {
    const t = i / seg;
    const w = wid * Math.sin(Math.pow(t, 0.6) * Math.PI) * (1 - t * 0.15);
    const y = len * t;
    const z = Math.sin(t * Math.PI * 0.5) * bend;
    pos.push(-w, y, z, w, y, z);
    uv.push(0, t, 1, t);
  }
  for (let i = 0; i < seg; i++) {
    const a = i * 2;
    idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function makePlant(scale, seed) {
  const grp = new THREE.Group();
  const leafMat = paintMat({
    color: 0x3e6b40, shadow: 0x18301d, hi: 0x7aa35c, rimColor: 0xbcd8a0,
    amb: 0x1c2a1e, rampLo: 0.24, rampHi: 0.70, rim: 0.6, spec: 0.06, shine: 24,
    side: THREE.DoubleSide
  });
  const stemMat = paintMat({ color: 0x4a6b3c, shadow: 0x1c2c18, hi: 0x6f8f52, amb: 0x1a2418, rampLo: 0.3, rampHi: 0.7 });
  const potMat = paintMat({ color: 0x6d5a44, shadow: 0x2e251c, hi: 0x8d7458, amb: 0x241d16, rampLo: 0.3, rampHi: 0.7, spec: 0.05, shine: 16, tex: TEX.wood, texAmt: 0.4 });

  // pot
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.16 * scale, 0.21 * scale, 0.30 * scale, 16), potMat);
  pot.position.y = 0.15 * scale;
  grp.add(pot);
  const soil = new THREE.Mesh(new THREE.CylinderGeometry(0.17 * scale, 0.17 * scale, 0.02, 16), paintMat({ color: 0x2a211a, shadow: 0x0e0b08, hi: 0x4a3a28, amb: 0x140f0c, rampLo: 0.3, rampHi: 0.7 }));
  soil.position.y = 0.30 * scale;
  grp.add(soil);

  const nLeaf = 11 + Math.floor(Math.random() * 6);
  for (let i = 0; i < nLeaf; i++) {
    const a = (i / nLeaf) * Math.PI * 2 + rand(-0.4, 0.4);
    const len = rand(0.7, 1.5) * scale;
    const wid = rand(0.05, 0.10) * scale;
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.008 * scale, 0.011 * scale, len * 0.85, 5), stemMat);
    stem.position.y = 0.30 * scale + len * 0.42;
    stem.rotation.z = rand(-0.35, 0.35);
    stem.rotation.x = rand(-0.35, 0.35);
    grp.add(stem);

    const lg = leafGeo(len * 0.85, wid, len * 0.22);
    const leaf = new THREE.Mesh(lg, leafMat);
    const pivot = new THREE.Group();
    pivot.position.y = 0.28 * scale;
    pivot.rotation.y = a;
    pivot.rotation.z = rand(0.5, 1.15);
    pivot.rotation.x = rand(-0.25, 0.25);
    pivot.add(leaf);
    leaf.position.set(0, len * 0.45, 0);
    grp.add(pivot);
  }
  return grp;
}

/* ----------------------------------------------------------------- chair */
function makeArmchair() {
  const grp = new THREE.Group();
  const leather = paintMat({
    color: 0x3a2a22, shadow: 0x120c09, hi: 0x7a5540, rimColor: 0xc99a72,
    amb: 0x1a1310, rampLo: 0.26, rampHi: 0.72, rim: 0.55, spec: 0.16, shine: 34,
    tex: TEX.leather, texAmt: 0.55
  });
  const wood = paintMat({ color: 0x3a2718, shadow: 0x150e08, hi: 0x6b4a2c, amb: 0x1c140e, rampLo: 0.3, rampHi: 0.7, spec: 0.1, shine: 26, tex: TEX.wood, texAmt: 0.4 });

  // seat cushion
  const seat = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), leather);
  seat.scale.set(0.38, 0.10, 0.34);
  seat.position.set(0, 0.40, 0);
  grp.add(seat);
  const seatBase = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.16, 0.66), leather);
  seatBase.position.set(0, 0.30, 0);
  grp.add(seatBase);

  // back
  const back = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 18), leather);
  back.scale.set(0.38, 0.34, 0.11);
  back.position.set(0, 0.72, -0.30);
  back.rotation.x = -0.10;
  grp.add(back);
  // tufting buttons
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) {
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.012, 8, 6), leather);
    b.position.set(-0.16 + c * 0.16, 0.84 - r * 0.13, -0.20 + r * 0.012);
    grp.add(b);
  }
  // wings
  for (const s of [-1, 1]) {
    const wing = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 14), leather);
    wing.scale.set(0.085, 0.30, 0.14);
    wing.position.set(s * 0.36, 0.68, -0.20);
    wing.rotation.z = s * 0.12;
    grp.add(wing);
  }
  // arms
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.42, 6, 14), leather);
    arm.rotation.x = Math.PI / 2;
    arm.position.set(s * 0.37, 0.55, 0.02);
    arm.scale.set(1, 1, 0.85);
    grp.add(arm);
    const armPad = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), leather);
    armPad.scale.set(0.09, 0.05, 0.24);
    armPad.position.set(s * 0.37, 0.62, 0.02);
    grp.add(armPad);
  }
  // legs
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.020, 0.22, 8), wood);
    leg.position.set(sx * 0.31, 0.11, sz * 0.26);
    leg.rotation.z = sx * 0.06;
    grp.add(leg);
  }
  // shadow
  const sh = shadowDecal(1.7, 1.5, 0.55);
  sh.position.y = 0.005;
  grp.add(sh);
  return grp;
}

/* ------------------------------------------------------------- the study */
function buildStudy() {
  const S = new THREE.Group();
  S.name = 'study';
  const ROOM = { w: 8, h: 3.6, d: 8 };

  const wallMat = paintMat({ color: 0xa89a84, shadow: 0x2f2c26, hi: 0xc6c0a8, amb: 0x2a2822, rampLo: 0.25, rampHi: 0.7, rim: 0.2, tex: TEX.wall, texAmt: 0.55 });
  const trimMat = paintMat({ color: 0x6d7a63, shadow: 0x232a20, hi: 0x93a084, amb: 0x22261e, rampLo: 0.26, rampHi: 0.72, rim: 0.25, spec: 0.05, shine: 18, tex: TEX.marble, texAmt: 0.5 });
  const floorMat = paintMat({ color: 0x50382a, shadow: 0x1a1009, hi: 0x7d5a3e, amb: 0x201610, rampLo: 0.28, rampHi: 0.7, spec: 0.12, shine: 30, tex: TEX.wood, texAmt: 0.5 });
  const goldMat = paintMat({ color: 0xc99a3f, shadow: 0x4a3008, hi: 0xf2d79a, amb: 0x3a2a10, rampLo: 0.22, rampHi: 0.66, rim: 0.3, spec: 0.10, shine: 26, tex: TEX.gold, texAmt: 0.85 });

  // floor
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(ROOM.w, ROOM.d), floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(0, 0, 0);
  S.add(floor);

  // back wall
  const back = new THREE.Mesh(new THREE.PlaneGeometry(ROOM.w, ROOM.h), wallMat);
  back.position.set(0, ROOM.h / 2, -3.4);
  S.add(back);
  // side walls
  const left = new THREE.Mesh(new THREE.PlaneGeometry(ROOM.d, ROOM.h), wallMat);
  left.rotation.y = Math.PI / 2;
  left.position.set(-4.0, ROOM.h / 2, 0);
  S.add(left);
  const right = new THREE.Mesh(new THREE.PlaneGeometry(ROOM.d, ROOM.h), wallMat);
  right.rotation.y = -Math.PI / 2;
  right.position.set(4.0, ROOM.h / 2, 0);
  S.add(right);
  // ceiling
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(ROOM.w, ROOM.d), paintMat({ color: 0x6a6355, shadow: 0x232019, hi: 0x8f887a, amb: 0x201e18, rampLo: 0.3, rampHi: 0.7 }));
  ceil.rotation.x = Math.PI / 2;
  ceil.position.set(0, ROOM.h, 0);
  S.add(ceil);

  // wainscot rail + panels on the back wall
  for (let i = 0; i < 3; i++) {
    const panel = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.0, 0.06), trimMat);
    panel.position.set(-2.4 + i * 2.4, 0.72, -3.33);
    S.add(panel);
    const frame = new THREE.Mesh(new THREE.BoxGeometry(1.72, 1.12, 0.03), wallMat);
    frame.position.set(-2.4 + i * 2.4, 0.72, -3.36);
    S.add(frame);
  }
  const rail = new THREE.Mesh(new THREE.BoxGeometry(ROOM.w, 0.09, 0.10), trimMat);
  rail.position.set(0, 1.28, -3.31);
  S.add(rail);

  // the gold mural panel behind the chair
  const mFrame = new THREE.Mesh(new THREE.BoxGeometry(3.72, 2.26, 0.05), trimMat);
  mFrame.position.set(-0.2, 2.25, -3.36);
  S.add(mFrame);
  const mural = new THREE.Mesh(new THREE.PlaneGeometry(3.5, 2.05), goldMat);
  mural.position.set(-0.2, 2.25, -3.30);
  S.add(mural);

  // window on the left wall, rain outside
  const winFrame = new THREE.Mesh(new THREE.BoxGeometry(0.10, 2.3, 2.2), trimMat);
  winFrame.position.set(-3.98, 1.9, 0.2);
  S.add(winFrame);
  const glassMat = new THREE.MeshBasicMaterial({ map: TEX.rain, transparent: true, opacity: 0.92, fog: false });
  const glass = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 2.1), glassMat);
  glass.rotation.y = Math.PI / 2;
  glass.position.set(-3.95, 1.9, 0.2);
  S.add(glass);
  // mullions
  for (let i = 0; i < 3; i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.1, 0.05), trimMat);
    m.position.set(-3.93, 1.9, -0.5 + i * 0.7);
    S.add(m);
  }
  const mull = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 2.0), trimMat);
  mull.position.set(-3.93, 1.9, 0.2);
  S.add(mull);

  // sunlight shaft through the window
  (function shaft() {
    const g = new THREE.BufferGeometry();
    const v = [];
    const quad = (a, b, c, d) => v.push(...a, ...b, ...c, ...a, ...c, ...d);
    quad([-3.9, 0.85, -0.8], [-3.9, 0.85, 1.2], [1.4, 0.02, 2.6], [1.4, 0.02, 0.4]);
    quad([-3.9, 2.95, -0.8], [-3.9, 2.95, 1.2], [1.4, 2.0, 2.6], [1.4, 2.0, 0.4]);
    g.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({
      color: 0xcfe3ee, transparent: true, opacity: 0.055, depthWrite: false,
      blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false
    }));
    m.renderOrder = 2;
    S.add(m);
    S.userData.shaft = m;
  })();

  // plants framing the composition
  const p1 = makePlant(1.5); p1.position.set(-2.55, 0, 0.55); S.add(p1);
  const p2 = makePlant(1.25); p2.position.set(2.35, 0, 0.9); S.add(p2);
  const p3 = makePlant(0.85); p3.position.set(-3.05, 0, -1.9); S.add(p3);

  // the chair
  const chair = makeArmchair();
  chair.position.set(0, 0, -1.55);
  S.add(chair);

  // side table with a small stack of books
  const tableTop = new THREE.Mesh(new THREE.CylinderGeometry(0.30, 0.30, 0.05, 20), trimMat);
  tableTop.position.set(1.45, 0.52, -1.35);
  S.add(tableTop);
  const tableLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.5, 10), trimMat);
  tableLeg.position.set(1.45, 0.26, -1.35);
  S.add(tableLeg);
  for (let i = 0; i < 3; i++) {
    const bk = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.035, 0.16), paintMat({
      color: [0x7a2f24, 0x2f4a3c, 0x3c3a5c][i], shadow: 0x140c08, hi: 0xa88a6a, amb: 0x1a1410, rampLo: 0.3, rampHi: 0.7, spec: 0.06, shine: 20
    }));
    bk.position.set(1.45 + rand(-0.02, 0.02), 0.56 + i * 0.037, -1.35 + rand(-0.02, 0.02));
    bk.rotation.y = rand(-0.2, 0.2);
    S.add(bk);
  }

  // dust motes in the light
  const motes = (function () {
    const N = 120, pos = new Float32Array(N * 3), seed = [];
    for (let i = 0; i < N; i++) {
      seed.push({ x: rand(-2.2, 1.4), y: rand(0.3, 2.6), z: rand(-0.6, 2.2), ph: rand(0, 6.3), sp: rand(0.02, 0.09) });
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const c = cnv(16, 16), x = c.getContext('2d');
    const rg = x.createRadialGradient(8, 8, 0, 8, 8, 8);
    rg.addColorStop(0, 'rgba(255,255,255,1)'); rg.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = rg; x.fillRect(0, 0, 16, 16);
    const m = new THREE.PointsMaterial({
      size: 0.012, map: new THREE.CanvasTexture(c), transparent: true, opacity: 0.5,
      depthWrite: false, blending: THREE.AdditiveBlending, color: 0xfff0d8, fog: false
    });
    const pts = new THREE.Points(g, m);
    pts.frustumCulled = false;
    S.add(pts);
    return { g, seed };
  })();

  S.userData.update = function (t) {
    const p = motes.g.attributes.position.array;
    for (let i = 0; i < motes.seed.length; i++) {
      const s = motes.seed[i];
      p[i * 3] = s.x + Math.sin(t * 0.21 + s.ph) * 0.18;
      p[i * 3 + 1] = s.y + Math.sin(t * s.sp * 6 + s.ph * 1.7) * 0.09;
      p[i * 3 + 2] = s.z + Math.cos(t * 0.17 + s.ph * 0.8) * 0.18;
    }
    motes.g.attributes.position.needsUpdate = true;
    if (S.userData.shaft) S.userData.shaft.material.opacity = 0.045 + 0.014 * Math.sin(t * 0.6);
  };

  S.userData.guSpot = { x: 0, y: 0.505, z: -1.40 };
  return S;
}
