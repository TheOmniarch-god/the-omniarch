const puppeteer=require('puppeteer'),path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'shell',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const p=await b.newPage(); await p.setViewport({width:900,height:900});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file://'+path.join(__dirname,'preview.html')+'?solo',{waitUntil:'load'});
await p.waitForFunction('window.__ready===true',{timeout:60000});
await p.evaluate(()=>window.__light([-0.85,0.32,0.30],0.035,1.0));
const prof = {px:0.62,py:1.19,pz:-1.39,tx:0,ty:1.185,tz:-1.39,fov:30};
const res = await p.evaluate(()=>{
  const g = window.__gu;
  const out = [];
  g.torso.traverse(o=>{ if(o.isMesh && o.geometry.type==='CylinderGeometry') { o.visible=false; out.push('hid cyl'); } });
  return out;
});
console.log(res.join(','));
await p.evaluate(o=>window.__look(o),prof); await p.evaluate(()=>window.__setTime(0));
await p.screenshot({path:'prev/x-nocyl.png'});
await b.close();})();
