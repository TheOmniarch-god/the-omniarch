const puppeteer=require('puppeteer'), fs=require('fs'), path=require('path');
const W=parseInt(process.env.W||'1280',10), H=parseInt(process.env.H||'720',10);
const times=(process.env.TIMES||'0').split(',').map(Number);
const OUT=process.env.OUT||path.join(__dirname,'prev');
const TAG=process.env.TAG||''; fs.mkdirSync(OUT,{recursive:true});
(async()=>{
const b=await puppeteer.launch({headless:'shell',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage','--hide-scrollbars']});
const p=await b.newPage(); await p.setViewport({width:W,height:H,deviceScaleFactor:1});
p.on('pageerror',e=>console.log('ERR',e.stack));
p.on('console',m=>{if(m.type()==='error')console.log('CONSOLE',m.text())});
await p.goto('file://'+path.join(__dirname,'preview.html')+((process.env.Q)?('?'+process.env.Q):''),{waitUntil:'load'});
await p.waitForFunction('window.__ready===true',{timeout:60000}).catch(e=>console.log('not ready'));
if(process.env.POSE) await p.evaluate(o=>window.__pose(o), JSON.parse(process.env.POSE));
if(process.env.LOOK) await p.evaluate(o=>window.__look(o), JSON.parse(process.env.LOOK));
for(const t of times){const d0=Date.now();await p.evaluate(tt=>window.__setTime(tt),t);
 await p.screenshot({path:path.join(OUT,`${TAG}t${String(t).replace('.','_')}.png`)});
 console.log('t='+t,(Date.now()-d0)+'ms');}
await b.close();})();
