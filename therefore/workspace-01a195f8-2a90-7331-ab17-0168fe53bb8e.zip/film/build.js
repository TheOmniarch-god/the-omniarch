const fs=require('fs'), path=require('path');
const rd=f=>fs.readFileSync(path.join(__dirname,f),'utf8');
const three=rd('three.min.js');
const files=['src/core.js','src/head.js','src/character.js','src/sets.js','src/film.js'];
const code=files.map(f=>'\n/* ==== '+f+' ==== */\n'+rd(f)).join('\n');
const html=`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Gu Zhen Ren — with hope</title>
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}canvas{display:block;width:100%;height:100%}</style>
</head><body><canvas id="c"></canvas>
<script>${three}</script>
<script>${code}</script>
</body></html>`;
fs.writeFileSync(path.join(__dirname,'..','film','preview.html'), html);
console.log('built preview.html', (html.length/1024).toFixed(0)+'KB');
