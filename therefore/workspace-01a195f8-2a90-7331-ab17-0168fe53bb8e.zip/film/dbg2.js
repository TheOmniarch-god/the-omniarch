const puppeteer=require('puppeteer'),path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'shell',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const p=await b.newPage(); await p.setViewport({width:1280,height:720});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file://'+path.join(__dirname,'preview.html')+'?solo',{waitUntil:'load'});
await p.waitForFunction('window.__ready===true',{timeout:60000});
await p.evaluate(()=>window.__light([-0.9,0.35,0.25],0.05,1.0));
await p.evaluate(o=>window.__look(o),{px:0.50,py:1.19,pz:-1.39,tx:0,ty:1.185,tz:-1.39,fov:34});
await p.evaluate(()=>window.__setTime(0));
await p.screenshot({path:'prev/prof.png'});
await b.close();})();
